
import org.junit.Test;

import static org.junit.Assert.assertEquals;

import static org.junit.Assert.assertFalse;

import static org.junit.Assert.assertTrue;

public class SentinelListTest extends ListTestBase {

    private List<String> list;

    @Override
    public List<String> createList() {
        return new SentinelList<>();
    }

    @Override
    public void newListEmpty() {
        super.newListEmpty();
    }

    @Override
    @Test(expected=EmptyException.class)
    public void newListNoFront() {
        super.newListNoFront();
    }

    @Override
    @Test(expected=EmptyException.class)
    public void newListNoBack() {
        super.newListNoBack();
    }

    @Override
    @Test
    public void insertFrontWorks() {
        super.insertFrontWorks();
    }

    @Test
    public void insertBackWorks() {
        super.insertBackWorks();
    }

    @Test
    public void insertFrontBackConsistent() {
        super.insertFrontBackConsistent();
    }

    @Test
    public void removeFrontWorks() {
        super.removeFrontWorks();
    }

    @Test
    public void removeBackWorks() {
        super.removeBackWorks();
    }

    @Test
    public void frontWorks() {
        super.frontWorks();
    }

    @Test
    public void backWorks() {
        super.backWorks();
    }

    @Test
    public void emptyWorks() {
        super.emptyWorks();
    }

    @Test
    public void lastWorks() {
        super.lastWorks();
    }

    @Test
    public void firstWorks() {
        super.firstWorks();
    }

    @Test
    public void insertAfterWorks() {
        super.insertAfterWorks();
    }

    @Test
    public void insertBeforeWorks() {
        super.insertBeforeWorks();
    }

    @Test
    public void removePosWorks() {
        super.removePosWorks();
    }

    @Test
    public void forwardIteratorWorks() {
        super.forwardIteratorWorks();
    }

    @Test
    public void backwardIteratorWorks() {
        super.forwardIteratorWorks();
    }

    @Test
    public void nextWorks() {
        super.nextWorks();
    }

    @Test
    public void previousWorks() {
        super.previousWorks();
    }

    @Test(expected=PositionException.class)
    public void previousAtFrontFails() {
        super.previousAtFrontFails();
    }

    @Test(expected=PositionException.class)
    public void nextAtBackFails() {
        super.nextAtBackFails();
    }

    @Test(expected=EmptyException.class)
    public void cantRemoveFrontWhenEmpty() {
        super.cantRemoveFrontWhenEmpty();
    }

    @Test(expected=EmptyException.class)
    public void cantRemoveBackWhenEmpty() {
        super.cantRemoveBackWhenEmpty();
    }

    @Test(expected=PositionException.class)
    public void testingOwnership() {
        super.testingOwnership();
    }

    @Test(expected=PositionException.class)
    public void removingInvalidatesOwner() {
        super.removingInvalidatesOwner();
    }

    @Test
    public void frontBackSameForOneElement() {
        super.frontBackSameForOneElement();
    }

    @Test
    public void lengthWorks() {
        super.lengthWorks();
    }

    @Test(expected=PositionException.class)
    public void insertingAfterFakePosition() {
        super.insertingAfterFakePosition();
    }

    @Test(expected=PositionException.class)
    public void insertingBeforeFakePosition() {
        super.insertingBeforeFakePosition(); 
    }

}

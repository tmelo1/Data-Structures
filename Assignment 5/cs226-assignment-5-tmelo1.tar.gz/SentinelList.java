import java.util.Iterator;

/**
*Linked list implementation with sentinel nodes.
*@param <T> generic types
*@author Tony Melo - tmelo1@jhu.edu
*/
public class SentinelList<T> implements List<T> {

    private static final class Node<T> implements Position<T> {
        Node<T> next;
        Node<T> prev;
        T data;
        List<T> color;

        @Override
        public T get() {
            return this.data;
        }

        @Override
        public void put(T t) {
            this.data = t;
        }
    }

    private final class ListIterator implements Iterator<T> {
        boolean forward;
        private Node<T> current;

        ListIterator(boolean f) {
            this.forward = f;
            if (this.forward) {
                this.current = SentinelList.this.head.next;
            } else {
                this.current = SentinelList.this.tail.prev;
            }
        }

        @Override
        public T next() {
            T t = this.current.get();
            if (this.forward) {
                this.current = this.current.next;
            } else {
                this.current = this.current.prev;
            }
            return t;
        }

        @Override
        public boolean hasNext() {
            if (this.forward) {
                return this.current != SentinelList.this.tail;
            } else {
                return this.current != SentinelList.this.head;
            }
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }
    }

    /** The sentinel at the front of the list. */
    private Node<T> head;

    /** The sentinel at the end. */
    private Node<T> tail;

    /** The number of elements in the list. */
    private int length;

    /** Make an empty list with sentinels. */
    public SentinelList() {
        this.tail = new Node<T>();
        this.head = new Node<T>();
        this.head.next = this.tail;
        this.tail.prev = this.head;
    }

    /**
    *Convert a position back into a node.
    *@param p the position to convert
    *@return the result
    *@throws PositionException if the position is invalid
    */
    private Node<T> convert(Position<T> p) throws PositionException {
        try {
            Node<T> n = (Node<T>) p;
            if (n.color != this) {
                throw new PositionException();
            }
            return n;
        } catch (NullPointerException | ClassCastException e) {
            throw new PositionException();
        }
    }

    @Override
    public boolean empty() {
        return this.length == 0;
    }

    @Override
    public int length() {
        return this.length;
    }

    @Override
    public boolean first(Position<T> p) {
        return this.head.next == p;
    }

    @Override
    public boolean last(Position<T> p) {
        return this.tail.prev == p;
    }

    @Override
    public Position<T> front() {
        if (this.empty()) {
            throw new EmptyException();
        }
        return this.head.next;
    }

    @Override
    public Position<T> back() throws EmptyException {
        if (this.empty()) {
            throw new EmptyException();
        }
        return this.tail.prev;
    }

    /**
    *Method to set next and previous pointers as well as data.
    *@param t the data
    *@param nxt the next node
    *@param p the previous node
    *@return the new node
    */
    private Node<T> initNode(T t, Node<T> nxt, Node<T> p) {
        Node<T> n = new Node<T>();
        n.data = t;
        n.color = this;
        n.next = nxt;
        nxt.prev = n;
        n.prev = p;
        p.next = n;
        return n;
    }

    @Override
    public Position<T> insertFront(T t) {
        if (this.empty()) {
            Node<T> n = this.initNode(t, this.tail, this.head);
            this.length++;
            return n;
        }
        Node<T> n = this.initNode(t, this.head.next, this.head);
        this.head.next.prev = n;
        this.length++;
        return n;
    }

    @Override
    public Position<T> insertBack(T t) {
        if (this.empty()) {
            Node<T> n = this.initNode(t, this.tail, this.head);
            this.length++;
            return n;
        }
        Node<T> n = this.initNode(t, this.tail, this.tail.prev);
        this.length++;
        return n;
    }

    @Override
    public void removeFront() throws EmptyException {
        if (this.empty()) {
            throw new EmptyException();
        }
        Node<T> n = this.head.next;
        this.head.next = n.next;
        n.next.prev = this.head;
        this.length--;
        n.color = null;
    }

    @Override
    public void removeBack() throws EmptyException {
        if (this.empty()) {
            throw new EmptyException();
        }
        Node<T> n = this.tail.prev;
        n.prev.next = this.tail;
        this.tail.prev = n.prev;
        this.length--;
        n.color = null;
    }

    @Override
    public Position<T> next(Position<T> p) throws PositionException {
        if (this.last(p)) {
            throw new PositionException();
        }
        return this.convert(p).next;
    }

    @Override
    public Position<T> previous(Position<T> p) throws PositionException {
        if (this.first(p)) {
            throw new PositionException();
        }
        return this.convert(p).prev;
    }

    @Override
    public Position<T> insertBefore(Position<T> p, T t)
    throws PositionException {
        if (this.empty()) {
            Node<T> n = this.initNode(t, this.tail, this.head);
            this.length++;
            return n;
        }
        Node<T> current = this.convert(p);
        Node<T> n = this.initNode(t, current, current.prev);
        current.prev = n;
        this.length++;
        return n;
    }

    @Override
    public Position<T> insertAfter(Position<T> p, T t)
    throws PositionException {
        if (this.empty()) {
            Node<T> n = this.initNode(t, this.tail, this.head);
            this.length++;
            return n;
        }
        Node<T> current = this.convert(p);
        Node<T> n = this.initNode(t, current.next, current);
        current.next.prev = n;
        current.next = n;
        this.length++;
        return n;
    }

    @Override
    public void remove(Position<T> p) throws PositionException {
        Node<T> n = this.convert(p);
        n.prev.next = n.next;
        n.next.prev = n.prev;
        n.color = null;
        this.length--;
    }

    @Override
    public Iterator<T> forward() {
        return new ListIterator(true);
    }

    @Override
    public Iterator<T> backward() {
        return new ListIterator(false);
    }

    @Override
    public Iterator<T> iterator() {
        return this.forward();
    }

    @Override
    public String toString() {
        String s = "[";
        for (Node<T> n = this.head.next; n.next != null; n = n.next) {
            s += n.get();
            if (n.next.data != null) {
                s += ", ";
            }
        }
        s += "]";
        return s;
    }
}

import org.junit.Before;
import org.junit.Test;
import java.util.Iterator;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

/**
 * Testing implementations of the List interface.
 *
 * The tests defined here apply to all implementations of the List
 * interface. However, they cannot be run directly as we don't know
 * which implementation to test or how to create an instance of it.
 *
 * The solution is to define a "template method" called createList()
 * that subclasses of this test override. The NodeListTest.java class,
 * for example, creates a suitable NodeList instance to be tested.
 *
 * (We could use a JUnit feature called "parameterized tests" to do
 * the same thing, however that feature is a bit more complex to use
 * than we would like.)
 *
 * Note that we (somewhat arbitrarily) choose to test lists of strings.
 * We could have gone for lists of integers or lists of whatever, but
 * strings seem convenient in any case: You can pick strings in such a
 * way as to make your test cases more readable.
 */
public abstract class ListTestBase {
    private List<String> list;
    private List<String> other;

    protected abstract List<String> createList();

    @Before
    public void setupListTests() {
        list = this.createList();
        other = this.createList();
    }

    @Test
    public void newListEmpty() {
        assertTrue(list.empty());
        assertEquals(0, list.length());
        assertEquals("[]", list.toString());
        int c = 0;
        for (String s: list) {
            System.out.println(c);
            c++;
        }
        assertEquals(0, c);
    }

    @Test(expected=EmptyException.class)
    public void newListNoFront() {
        Position<String> p = list.front();
    }

    @Test(expected=EmptyException.class)
    public void newListNoBack() {
        Position<String> p = list.back();
    }

    @Test
    public void insertFrontWorks() {
        list.insertFront("One");
        list.insertFront("Two");
        list.insertFront("Three");
        assertFalse(list.empty());
        assertEquals(3, list.length());
        assertEquals("[Three, Two, One]", list.toString());
        int c = 0;
        for (String s: list) {
            c++;
        }
        assertEquals(3, c);
    }

    @Test
    public void insertBackWorks() {
        list.insertBack("One");
        list.insertBack("Two");
        list.insertBack("Three");
        assertFalse(list.empty());
        assertEquals(3, list.length());
        assertEquals("[One, Two, Three]", list.toString());
        int c = 0;
        for (String s: list) {
            c++;
        }
        assertEquals(3, c);
    }

    @Test
    public void insertFrontBackConsistent() {
        Position<String> f = list.insertFront("Front");
        assertEquals("Front", f.get());
        Position<String> b = list.insertBack("Back");
        assertEquals("Back", b.get());
        assertNotEquals(f, b);
        assertTrue(list.first(f));
        assertTrue(list.last(b));
        Position<String> x;
        x = list.front();
        assertEquals(f, x);
        x = list.back();
        assertEquals(b, x);
    }

    @Test
    public void removeFrontWorks() {
        list.insertFront("One");
        list.insertFront("Two");
        list.insertFront("Three");
        list.removeFront();
        list.removeFront();
        assertFalse(list.empty());
        assertEquals(1, list.length());
        assertEquals("[One]", list.toString());

        int c = 0;
        for (String s: list) {
            c++;
        }
        assertEquals(1, c);
    }

    @Test
    public void removeBackWorks() {
        list.insertFront("One");
        list.insertFront("Two");
        list.insertFront("Three");
        list.removeBack();
        list.removeBack();
        assertFalse(list.empty());
        assertEquals(1, list.length());
        assertEquals("[Three]", list.toString());
        int c = 0;
        for (String s: list) {
            c++;
        }
        assertEquals(1, c);
    }

    // TODO You need to add *many* more test cases here, ideally before you
    // even start working on SentinelList!

    @Test
    public void frontWorks() {
        Position<String> n = list.insertFront("This is the front now");
        assertEquals("This is the front now", n.get());
        Position<String> compare = list.front();
        assertEquals(n, compare);
    }

    @Test
    public void backWorks() {
        Position<String> b = list.insertBack("This is the back now");
        assertEquals("This is the back now", b.get());
        Position<String> compare = list.back();
        assertEquals(b, compare);
    }

    @Test
    public void emptyWorks() {
        Position<String> a = list.insertBack("hmm");
        assertFalse(list.empty());
    }

    @Test
    public void lastWorks() {
        Position<String> l = list.insertBack("New back");
        assertTrue(list.last(l));
    }

    @Test
    public void firstWorks() {
        Position<String> f = list.insertFront("New Front");
        assertTrue(list.first(f));
    }

    @Test
    public void insertAfterWorks() {
        Position<String> b = list.insertBack("Inserting after this");
        Position a = list.insertAfter(b, "Inserted after");
        assertEquals(a, list.next(b));
    }

    @Test
    public void insertBeforeWorks() {
        Position<String> d = list.insertFront("Inserting before this");
        Position<String> b = list.insertBefore(d, "Inserted before");
        assertEquals(b, list.previous(d));
        assertEquals(d, list.next(b));
    }

    @Test
    public void removePosWorks() {
        Position<String> x = list.insertBack("Remove this");
        Position<String> b = list.insertBefore(x, "comparison");
        list.remove(x);
        assertTrue(list.last(b));
    }

    @Test
    public void forwardIteratorWorks() {
        Iterator<String> forIt = list.forward();
        String testString = "[";
        for (String s: list) {
            testString += s;
            if (forIt.hasNext()) {
                testString += ", ";
            }
        }
        testString += "]";
        assertEquals(testString, list.toString());
    }

    @Test
    public void backwardIteratorWorks() {
        list.insertFront("First");
        list.insertBack("Second");
        list.insertBack("Third");
        String testString = "[";
        for (Iterator<String> backIt = list.backward(); backIt.hasNext(); ) {
            String s = backIt.next();
            testString += s;
            if (backIt.hasNext()) {
                testString += ", ";
            }
        }
        testString += "]";
        assertEquals("[Third, Second, First]", testString);
    }

    @Test
    public void nextWorks() {
        Position<String> f = list.insertFront("previous");
        Position<String> n = list.insertAfter(f, "next");
        assertEquals("[previous, next]", list.toString());
        assertEquals(n, list.next(f));
    }

    @Test
    public void previousWorks() {
        Position<String> p = list.insertBack("after");
        Position<String> b = list.insertBefore(p, "previous");
        assertEquals("[previous, after]", list.toString());
        assertEquals(b, list.previous(p));
    }

    @Test(expected=PositionException.class)
    public void previousAtFrontFails() {
        Position<String> f = list.insertFront("front");
        assertEquals(f, list.front());
        list.previous(f);
    }

    @Test(expected=PositionException.class)
    public void nextAtBackFails() {
        Position<String> b = list.insertBack("back");
        assertEquals(b, list.back());
        list.next(b);
    }

    @Test(expected=EmptyException.class)
    public void cantRemoveFrontWhenEmpty() {
        list.removeFront();
    }

    @Test(expected=EmptyException.class)
    public void cantRemoveBackWhenEmpty() {
        list.removeBack();
    }

    @Test(expected=PositionException.class)
    public void testingOwnership() {
        Position<String> l = list.insertFront("belongs to list");
        Position<String> o = other.insertFront("belongs to other");
        list.remove(o);
    }

    @Test(expected=PositionException.class)
    public void removingInvalidatesOwner() {
        Position<String> t = list.insertFront("checking if this actually gets invalidated");
        list.removeFront();
        assertTrue(list.empty());
        list.remove(t);
    }

    @Test
    public void frontBackSameForOneElement() {
        Position<String> fb = list.insertBack("testing");
        assertTrue(list.first(fb));
        assertTrue(list.last(fb));
        list.removeFront();
        assertTrue(list.empty());
    }

    @Test
    public void lengthWorks() {
        list.insertFront("one");
        list.insertFront("two");
        assertEquals(2, list.length());
        int t = 0;
        for (String s: list) {
            t++;
        }
        assertEquals(t, list.length());
    }

    @Test(expected=PositionException.class)
    public void insertingAfterFakePosition() {
        Position<String> fake = list.insertFront("huh");
        Position<String> nope = other.insertFront("hmm");
        other.insertAfter(fake, "");
    }

    @Test(expected=PositionException.class)
    public void insertingBeforeFakePosition() {
        Position<String> faker = other.insertBack("wow");
        Position<String> noway = list.insertBack("whoa");
        list.insertBefore(faker, "what?");
    }
}

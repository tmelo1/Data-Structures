/**
*Simple counter interface.
*/
public interface Counter {

    /** Current value of this counter.
    *@return the value of the counter
    */
    int value();

    /** Increment this counter. */
    void up();

    /** Decrement this counter. */
    void down();
}

/**
*Prints all unique numbers from command line arguments.
*@Author Tony Melo
*/
public final class Unique {

    /** Hide default constructor. */
    private Unique() { }

    /**
    *Checks if number given as argument repeats.
    *Prints all numbers given only once, regardless of repeats.
    *@param nums
    *Array of strings from command line
    */
    public static void printUniquely(String[] nums) {
        boolean found = false;
        for (int i = 0; i < nums.length; i++) {
            for (int c = 0; c < i; c++) {
                try {
                    if (Integer.parseInt(nums[i])
                        == Integer.parseInt(nums[c])) {
                        found = true;
                        break;
                    }
                } catch (NumberFormatException e) {
                    System.err.println("Argument " + nums[i] + " cannot be parsed.");
                    break;
                }
            }
            if (!found) {
                System.out.println(nums[i]);
            }
            found = false;
        }
    }

    /**
    *Main method of program.
    *Calls printUniquely and checks for invalid argument numbers.
    *@param args
    *Command line arguments.
    */
    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("No arguments entered. Exiting.");
            System.exit(0);
        }
        printUniquely(args);
    }
}

/**
*A resetable counter that increments and decrements by 1. Starts at 0.
*@Author Tony Melo - tmelo1@jhu.edu
*/
public class BasicCounter implements ResetableCounter {

    /** Will hold the value of the counter. */
    private int value;

    /** Increment value of counter by 1. */
    public void up() {
        this.value++;
    }

    /** Decrement count by one. */
    public void down() {
        this.value--;
    }

    /**
    *Returns the value of the counter.
    *@return value   The counter's current value.
    */
    public int value() {
        return this.value;
    }

    /** Reset the counter value back to 0. */
    public void reset() {
        this.value = 0;
    }

    /** Main method here just to test counter.
    *@param args
    *Command line arguments
    */
    public static void main(String[] args) {
        BasicCounter c = new BasicCounter();
        assert c.value() == 0;
        c.up();
        assert c.value() == 1;
        c.down();
        assert c.value() == 0;
        c.down();
        assert c.value() == -1;
        c.reset();
        assert c.value() == 0;
    }
}


/** Extension of counter. Supports reset method.
*@Author Tony Melo
 */
public interface ResetableCounter extends Counter {

    /** Resets the value of the counter. */
    void reset();

}

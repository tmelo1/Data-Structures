/** More complex counter.
*Starts at input value and increments by specified amount.
*@Author Tony Melo - tmelo1@jhu.edu
*/
public class FlexibleCounter implements ResetableCounter {

    /** Increment and decrement by this number. */
    private int increment;

    /** Holds the value of counter. */
    private int value;

    /** Remember our starting point for reset function. */
    private int startingInt;

    /** Creates a counter with initial value start and increment i.
    *@param start   the starting value
    *@param i       the increment value
    */
    public FlexibleCounter(int start, int i) {
        this.value = start;
        if (i < 0) {
            i *= -1;
        }
        this.increment = i;
        this.startingInt = start;
    }

    @Override
    public void up() {
        this.value += this.increment;
    }

    @Override
    public void down() {
        this.value -= this.increment;
    }

    @Override
    public void reset() {
        this.value = this.startingInt;
    }

    /** Returns the value of the counter.
    *@return value    the stored counter value
    */
    public int value() {
        return this.value;
    }

    /** More assertion tests.
    *@param args    command line arguments
    */
    public static void main(String[] args) {
        FlexibleCounter test = new FlexibleCounter(10, 7);
        test.up();
        assert test.value() == 17;
        test.up();
        assert test.value() == 24;
        test.reset();
        assert test.value() == 10;
        test.down();
        assert test.value() == 3;

    }
}

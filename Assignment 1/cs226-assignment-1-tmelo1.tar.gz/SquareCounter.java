/** Increments by squaring, decrements by square roots. Starts at 2. 
*@Author Tony Melo
*/
public class SquareCounter implements ResetableCounter {

    /** No magic numbers. This is the number 2. */
    private static final int TWO = 2;

    /** The number four. */
    private static final int FOUR = 4;

    /** Stores the counter value. */
    private int value;

    /** Exists for code reuse. */
    public SquareCounter() {
        this.reset();
    }

    @Override
    public void up() {
        this.value *= this.value;
    }

    @Override
    public void down() {
        double root = java.lang.Math.sqrt(this.value);
        if ((this.value % root) == 0) {
            this.value = (int) root;
        } else {
            this.value = (int) root + 1;
        }
    }

    @Override
    public void reset() {
        this.value = TWO;
    }

    @Override
    public int value() {
        return this.value;
    }

    /** Main method to test counter with assertions.
    *@param args
    *Command line arguments
    */
    public static void main(String[] args) {
        SquareCounter test = new SquareCounter();
        assert test.value() == TWO;
        test.up();
        assert test.value() == FOUR;
        test.down();
        assert test.value() == TWO;
        test.down();
        assert test.value() == TWO;
        test.up();
        assert test.value() == FOUR;
        test.reset();
        assert test.value() == TWO;
    }
}

import java.util.Scanner;
import java.util.StringTokenizer;
/**
    This is a sample-solution for Problem 1 on Assignment 1. It doesn't use
    anything fancy, just stuff you should have known from your previous Java
    courses. (Well, and some stuff checkstyle would have told you about.)
    Tony Melo - tmelo1@jhu.edu
*/
public final class Unique {

    /** Array to store unique numbers */
    private static Array<Integer> data;
    /** how many slots in data are used? */
    private static int used;
    /** The number ten. */
    private static final int TEN = 10;
    /** Default size of our Array. */
    private static final int DEFAULT_SIZE = TEN;

    /** Make checkstyle happy. */
    private Unique() {}

    /**
    *Checks if the number exists in the array.
    *@param value         The value to search for
    *@return i            The index of the value if found, -1 otherwise.
    */
    private static int find(Integer value) {
        for (int i = 0; i < used; i++) {
            if (data.get(i) == value) {
                return i;
            }
        }
        return -1;
    }

    /**
    *Insert the value into the array if it is unique.
    *@param value         The value to insert
    */
    private static void insert(Integer value) {
        int position = find(value);
        if (position < 0) {
            data.put(used, value);
            used += 1;
        }
    }

    /**
    *Resize the array once it gets too full.
    */
    private static void resize() {
        int newSize = data.length() * 2;
        Array<Integer> newData = new SimpleArray<Integer>(newSize, 0);
        for (int i = 0; i < used; i++) {
            newData.put(i, data.get(i));
        }
        data = newData;
    }

    /**
    *Convert array of string into Integers.
    *@param in           The string to convert
    *@param inerror      Check if we've thrown an exception
    */
    private static void parse(String in, boolean inerror) {
        StringTokenizer st = new StringTokenizer(in, " ");
        Integer n = 0;
        while (st.hasMoreTokens()) {

            inerror = false;
            try {
                n = Integer.parseInt(st.nextToken());
            } catch (NumberFormatException e) {
                System.err.println("Ignored invalid argument");
                inerror = true;
            }
            if (!inerror) {
                if (used == data.length()) {
                    resize();
                }
                insert(n);
            }
        }
    }

    /**
        Print only unique integers out of given command line arguments.

        @param args Command line arguments.
    */
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        data = new SimpleArray<Integer>(DEFAULT_SIZE, 0);
        boolean inerror = false;
        Integer n = 0;
        String input = "";
        while (kb.hasNextLine()) {
            input = kb.nextLine();
            parse(input, inerror);
        }
        // output unique numbers in array order
        for (int i = 0; i < used; i++) {
            System.out.println(data.get(i));
        }
    }
}

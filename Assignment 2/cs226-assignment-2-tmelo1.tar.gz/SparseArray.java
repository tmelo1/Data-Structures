import java.util.Iterator;

/**
*Class to create generic Sparse Array linked list implementation.
*Smarter choice for when you're unsure of whether or not you're going to be using
*Every single slot in your array, since it uses less space. A normal array would be
*more efficient in cases where you know you'll use all of or most of the space an
*array requires since insertion and accessing elements would be much more efficient.
*@param <T>         generic type T
*/
public class SparseArray<T> implements Array<T> {

    private static final class Node<T> {

        /** Value to store in node. */
        protected T data;

        /** Node index. */
        protected int index;

        /** Next node in list. */
        protected Node<T> next;

        /**
        *Constructor for generic node object.
        *@param t          value stored
        *@param i          index in sparse array
        *@param n          next node pointer
        */
        private Node(T t, int i, Node<T> n) {
            this.data = t;
            this.index = i;
            this.next = n;
        }

    }

    private class SparseArrayIterator implements Iterator<T> {
        Node<T> curr;

        SparseArrayIterator() {
            this.curr = SparseArray.this.head;
        }

        @Override
        public T next() {
            T t = this.curr.next.data;
            this.curr = this.curr.next; 
            return t;
        }

        @Override
        public boolean hasNext() {
            return this.curr.next != SparseArray.this.tail;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }
    }

    /** Head node. */
    protected Node<T> head;

    /** Tail node. */
    protected Node<T> tail;

    /** Length of list. */
    protected int length;

    /** Current node. */
    protected Node<T> current;

    /** Initial value. */
    protected T initial;

    /** Actual number of elements. */
    protected int size;

    /**
    *Create a linked-list Sparse Array object.
    *@param l          the length of the list
    *@param t          the default value
    */
    public SparseArray(int l, T t) {
        this.initial = t;
        this.length = l;
        this.tail = new Node<T>(null, this.length, null);
        this.head = new Node<T>(null, -1, this.tail);
        this.current = this.head;
        this.size = 0;
    }

    @Override
    public void put(int i, T t) throws IndexException {
        if (i >= this.length || i < 0) {
            throw new IndexException();
        }
        if (this.size == 0) {
            Node<T> n = new Node<T>(t, i, null);
            this.head.next = n;
            this.tail.next = n;
            this.current = n;
            this.size++;
            return;
        }
        Node<T> temp = this.current;
        Node<T> n = new Node<T>(t, i, null);
        while (this.current.next != null && this.current.next.index < i) {
            this.current = this.current.next;
        }
        if (this.current.next == null) {
            this.current.next = n;
            n.next = this.tail;
        }
        if (this.current.next.index == i) {
            this.current.next.data = t;
        } else if (this.current.next.index > i) {
            n.next = this.current.next;
            this.current.next = n;
        }
        this.current = temp;
        this.size++;
        return;
    }

    @Override
    public int length() {
        return this.length;
    }

    @Override
    public T get(int i) throws IndexException {
        if (this.size == 0) {
            return this.initial;
        }
        if (i < 0 || i >= this.length) {
            throw new IndexException();
        }
        Node<T> temp = this.current;
        while (this.current.index < i) {
            this.current = this.current.next;
        }
        if (this.current.index == i) {
            return this.current.data;
        }
        this.current = temp;
        return this.initial;
    }

    @Override
    public Iterator<T> iterator() {
        return new SparseArrayIterator();
    }

    public static void main(String[] args) {
        SparseArray<Integer> test = new SparseArray<>(10, 0);
        for (int i = 0; i < 10; i++) {
            test.put(i, i);
        }
        for (Integer i: test) {
            System.out.println(test.get(i));
        }
    }
}

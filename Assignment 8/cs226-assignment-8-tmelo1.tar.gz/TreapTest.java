public final class TreapTest extends TreeTestBase {

    private Map<Integer, Integer> tree = this.createTree();

    @Override
    public Map<Integer, Integer> createTree() {
        return new TreapMap<>();
    }
}

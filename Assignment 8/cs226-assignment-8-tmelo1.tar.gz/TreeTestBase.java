import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public abstract class TreeTestBase {

    private Map<Integer, Integer> tree;

    protected abstract Map<Integer, Integer> createTree();

    @Before
    public void setupTreeTests() {
        tree = this.createTree();
    }

    @Test
    public void testInit() {
        assertEquals(0, tree.size());
        int c = 0;
        for (Integer i: tree) {
            c++;
        }
        assertEquals(0, c);
    }

    @Test(expected=IllegalArgumentException.class)
    public void puttingNullKeys() {
        tree.put(null, 1);
    }

    @Test(expected=IllegalArgumentException.class)
    public void gettingNullKeys() {
        tree.get(null);
    }

    @Test(expected=IllegalArgumentException.class)
    public void insertingNullKey() {
        tree.insert(null, 2);
    }

    @Test(expected=IllegalArgumentException.class)
    public void removingNullKey() {
        tree.remove(null);
    }

    @Test
    public void insertWorks() {
        tree.insert(1, 2);
        tree.insert(3, 4);
        tree.insert(5, 6);
        assertEquals("{1: 2, 3: 4, 5: 6}", tree.toString());
    }

    @Test
    public void removeWorks() {
        tree.insert(1, 2);
        tree.insert(3, 4);
        tree.insert(5, 6);
        assertEquals("{1: 2, 3: 4, 5: 6}", tree.toString());
        int v = tree.remove(1);
        assertEquals("{3: 4, 5: 6}", tree.toString());
        assertEquals(2, v);
    }

    @Test
    public void iteratorWorks() {
        tree.insert(1, 2);
        tree.insert(3, 4);
        tree.insert(5, 6);
        String test = "";
        for (Integer i: tree) {
            test += tree.get(i) + " ";
        }
        assertEquals("2 4 6 ", test);
    }

    @Test
    public void putWorks() {
        tree.insert(1, 2);
        assertEquals(2, (int) tree.get(1));
        tree.put(1, 5);
        assertEquals(5, (int) tree.get(1));
    }

    @Test
    public void hasWorks() {
        tree.insert(1, 2);
        tree.insert(3, 4);
        tree.insert(7, 8);
        assertTrue(tree.has(1));
        assertTrue(tree.has(3));
        assertFalse(tree.has(5));
    }

    @Test
    public void sizeWorks() {
        tree.insert(1, 2);
        tree.insert(3, 4);
        tree.insert(5, 6);
        int c = 0;
        for (Integer i: tree) {
            c++;
        }
        assertEquals(c, tree.size());
    }

    @Test(expected=IllegalArgumentException.class)
    public void cantInsertDuplicates() {
        tree.insert(1, 2);
        tree.insert(1, 3);
    }

    @Test
    public void getWorks() {
        tree.insert(5, 9);
        assertEquals(9, (int)tree.get(5));
    }

    @Test(expected=IllegalArgumentException.class)
    public void cantGetWhatsNotThere() {
        tree.get(9);
    }

    @Test(expected=IllegalArgumentException.class)
    public void cantPutWhatIsntThereEither() {
        tree.put(8, 9);
    }
}

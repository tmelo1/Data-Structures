import java.util.Random;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;

/**
*Implementation of probabilistically balanced BSTMap, TreapMap.
*@param <K> key type
*@param <V> value type
*@author Tony Melo - tmelo1@jhu.edu
*/
public class TreapMap<K extends Comparable<? super K>, V>
    implements OrderedMap<K, V> {

    private static final Random R = new Random();

    private final class Node {
        Node left;
        Node right;
        K key;
        V value;
        int priority;

        Node(K k, V v) {
            this.key = k;
            this.value = v;
            this.priority = R.nextInt();
            this.right = null;
            this.left = null;
        }
    }

    private Node root;
    private int size;
    private StringBuilder stringBuilder;

    /**
    *Construct a new TreapMap.
    */
    public TreapMap() {
        this.size = 0;
    }

    @Override
    public int size() {
        return this.size;
    }

    @Override
    public void insert(K k, V v) {
        if (k == null) {
            throw new IllegalArgumentException("null key not allowed");
        }
        this.root = this.insert(this.root, k, v);
        this.size++;
    }

    private Node insert(Node n, K k, V v) {
        if (n == null) {
            return new Node(k, v);
        }
        int compare = k.compareTo(n.key);
        if (compare < 0) {
            n.left = this.insert(n.left, k, v);
            if (n.priority > n.left.priority) {
                return this.rightRotation(n);
            }
        } else if (compare > 0) {
            n.right = this.insert(n.right, k, v);
            if (n.priority > n.right.priority) {
                return this.leftRotation(n);
            }
        } else {
            throw new IllegalArgumentException("key " + k + " is a duplicate");
        }
        return n;
    }

    private Node find(K k) {
        if (k == null) {
            throw new IllegalArgumentException("null key not allowed");
        }
        Node n = this.root;
        while (n != null) {
            int compare = k.compareTo(n.key);
            if (compare < 0) {
                n = n.left;
            } else if (compare > 0) {
                n = n.right;
            } else {
                return n;
            }
        }
        return null;
    }

    private Node actuallyFind(K k) {
        Node n = this.find(k);
        if (n == null) {
            throw new IllegalArgumentException("key " + k + " not found");
        }
        return n;
    }

    @Override
    public boolean has(K k) {
        if (k == null) {
            return false;
        }
        return this.find(k) != null;
    }

    @Override
    public void put(K k, V v) {
        Node n = this.actuallyFind(k);
        n.value = v;
    }

    @Override
    public V get(K k) {
        Node n = this.actuallyFind(k);
        return n.value;
    }

    private Node rightRotation(Node n) {
        Node l = n.left;
        n.left = l.right;
        l.right = n;
        return l;
    }

    private Node leftRotation(Node n) {
        Node rn = n.right;
        n.right = rn.left;
        rn.left = n;
        return rn;
    }

    private Node min(Node n) {
        Node temp = n;
        while (temp.left != null) {
            temp = temp.left;
        }
        return temp;
    }

    @Override
    public V remove(K k) {
        Node toDelete = this.find(k);
        this.root = this.remove(this.root, k);
        this.size--;
        return toDelete.value;
    }

    private Node remove(Node n, K k) {
        if (n == null) {
            throw new IllegalArgumentException("key " + k  + " not found");
        }
        int compare = k.compareTo(n.key);
        if (compare < 0) {
            n.left = this.remove(n.left, k);
        } else if (compare > 0) {
            n.right = this.remove(n.right, k);
        } else {
            if (n.left == null) {
                return n.right;
            } else if (n.right == null) {
                return n.left;
            } else {
                Node min = this.min(n.right);
                n.key = min.key;
                n.right = this.remove(n.right, n.key);
            }
        }
        return n;
    }

    // Recursively add keys from subtree rooted at given node
    // into the given list.
    private void iteratorHelper(Node n, List<K> keys) {
        if (n == null) {
            return;
        }
        this.iteratorHelper(n.left, keys);
        keys.add(n.key);
        this.iteratorHelper(n.right, keys);
    }

    @Override
    public Iterator<K> iterator() {
        List<K> keys = new ArrayList<K>();
        this.iteratorHelper(this.root, keys);
        return keys.iterator();
    }

    // If we don't have a StringBuilder yet, make one;
    // otherwise just reset it back to a clean slate.
    private void setupStringBuilder() {
        if (this.stringBuilder == null) {
            this.stringBuilder = new StringBuilder();
        } else {
            this.stringBuilder.setLength(0);
        }
    }

    // Recursively append string representations of keys and
    // values from subtree rooted at given node.
    private void toStringHelper(Node n, StringBuilder s) {
        if (n == null) {
            return;
        }
        this.toStringHelper(n.left, s);
        s.append(n.key);
        s.append(": ");
        s.append(n.value);
        s.append(", ");
        this.toStringHelper(n.right, s);
    }

    @Override
    public String toString() {
        this.setupStringBuilder();
        this.stringBuilder.append("{");

        this.toStringHelper(this.root, this.stringBuilder);

        int length = this.stringBuilder.length();
        if (length > 1) {
            // If anything was appended at all, get rid of
            // the last ", " the toStringHelper put in.
            this.stringBuilder.setLength(length - 2);
        }
        this.stringBuilder.append("}");

        return this.stringBuilder.toString();
    }


}

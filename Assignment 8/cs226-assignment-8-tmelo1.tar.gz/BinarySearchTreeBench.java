import com.github.phf.jb.Bench;
import com.github.phf.jb.Bee;

import java.util.Random;

public final class BinarySearchTreeBench {

    private static final int SIZE = 1000;
    private static final Random RAND = new Random();

    private BinarySearchTreeBench() {}

    private static void insertSorted(Map<Integer, Integer> t) {
        for (int i = SIZE; i > 0; i--) {
            t.insert(i, RAND.nextInt(SIZE));
        }
    }

    private static void insertRandomKeys(Map<Integer, Integer> t) {
        for (int i = 0; i < SIZE; i++) {
            try {
                t.insert(RAND.nextInt(SIZE), i);
            } catch (IllegalArgumentException e) {
                continue;
            }
        }
    }

    private static void randomRemove(Map<Integer, Integer> t) {
        for (int i = 0; i < SIZE; i++) {
            try {
                t.remove(RAND.nextInt(SIZE));
            } catch (IllegalArgumentException e) {
                continue;
            }
        }
    }

    private static void removeLinear(Map<Integer, Integer> t) {
        for (int i = SIZE; i > 0; i--) {
            t.remove(i);
        }
    }

    private static void randomLookup(Map<Integer, Integer> t) {
        for (int i = 0; i < SIZE; i++) {
            try {
                boolean h = t.has(RAND.nextInt(SIZE));
            } catch (IllegalArgumentException e) {
                continue;
            }
        }
    }

    private static void linearLookup(Map<Integer, Integer> t) {
        for (int i = SIZE; i > 0; i--) {
            boolean h = t.has(i);
        }
    }

    private static void mixedOperations(Map<Integer, Integer> t) {
        for (int i = 0; i < SIZE; i++) {
            if (RAND.nextInt(SIZE*2) < SIZE) {
                try {
                    t.remove(RAND.nextInt(SIZE));
                } catch (IllegalArgumentException e) {
                    continue;
                }
            } else {
                try {
                    t.insert(RAND.nextInt(SIZE), i);
                } catch (IllegalArgumentException e) {
                    continue;
                }
            }
        }
    }

    @Bench
    public static void randomSequenceBST(Bee b) {
        for (int c = 0; c < b.reps(); c++) {
            b.stop();
            Map<Integer, Integer> t = new BinarySearchTreeMap<>();
            insertRandomKeys(t);
            b.start();
            mixedOperations(t);
        }
    }

    @Bench
    public static void insertLinearBST(Bee b) {
        for (int c = 0; c < b.reps(); c++) {
            b.stop();
            Map<Integer, Integer> t = new BinarySearchTreeMap<>();
            b.start();
            insertSorted(t);
        }
    }

    @Bench
    public static void insertRandomBST(Bee b) {
        for (int c = 0; c < b.reps(); c++) {
            b.stop();
            Map<Integer, Integer> t = new BinarySearchTreeMap<>();
            b.start();
            insertRandomKeys(t);
        }
    }

    @Bench
    public static void randomLookupsBST(Bee b) {
        for (int c = 0; c < b.reps(); c++) {
            b.stop();
            Map<Integer, Integer> t = new BinarySearchTreeMap<>();
            insertSorted(t);
            b.start();
            randomLookup(t);
        }
    }

    @Bench
    public static void linearLookupsBST(Bee b) {
        for (int c = 0; c < b.reps(); c++) {
            b.stop();
            Map<Integer, Integer> t = new BinarySearchTreeMap<>();
            insertSorted(t);
            b.start();
            linearLookup(t);
        }
    }

    @Bench
    public static void randomRemovesBST(Bee b) {
        for (int c = 0; c < b.reps(); c++) {
            b.stop();
            Map<Integer, Integer> t = new BinarySearchTreeMap<>();
            insertSorted(t);
            b.start();
            randomRemove(t);
        }
    }


    @Bench
    public static void randomSequenceAVL(Bee b) {
        for (int c = 0; c < b.reps(); c++) {
            b.stop();
            Map<Integer, Integer> t = new AVLTreeMap<>();
            try {
                insertRandomKeys(t);
            } catch (Exception e) {
                continue;
            }
            b.start();
            try {
                mixedOperations(t);
            } catch (Exception e) {
                continue;
            }
        }
    }

    @Bench
    public static void insertLinearAVL(Bee b) {
        for (int c = 0; c < b.reps(); c++) {
            b.stop();
            Map<Integer, Integer> t = new AVLTreeMap<>();
            b.start();
            insertSorted(t);
        }
    }

    @Bench
    public static void insertRandomAVL(Bee b) {
        for (int c = 0; c < b.reps(); c++) {
            b.stop();
            Map<Integer, Integer> t = new AVLTreeMap<>();
            b.start();
            insertRandomKeys(t);
        }
    }

    @Bench
    public static void randomLookupsAVL(Bee b) {
        for (int c = 0; c < b.reps(); c++) {
            b.stop();
            Map<Integer, Integer> t = new AVLTreeMap<>();
            insertSorted(t);
            b.start();
            randomLookup(t);
        }
    }

    @Bench
    public static void linearLookupsAVL(Bee b) {
        for (int c = 0; c < b.reps(); c++) {
            b.stop();
            Map<Integer, Integer> t = new AVLTreeMap<>();
            insertSorted(t);
            b.start();
            linearLookup(t);
        }
    }

    @Bench
    public static void randomRemovesAVL(Bee b) {
        for (int c = 0; c < b.reps(); c++) {
            b.stop();
            Map<Integer, Integer> t = new AVLTreeMap<>();
            insertSorted(t);
            b.start();
            randomRemove(t);
        }
    }

    @Bench
    public static void randomSequenceTreap(Bee b) {
        for (int c = 0; c < b.reps(); c++) {
            b.stop();
            Map<Integer, Integer> t = new TreapMap<>();
            try {
                insertRandomKeys(t);
            } catch (Exception e) {
                continue;
            }
            b.start();
            try {
                mixedOperations(t);
            } catch (Exception e) {
                continue;
            }
        }
    }

    @Bench
    public static void insertLinearTreap(Bee b) {
        for (int c = 0; c < b.reps(); c++) {
            b.stop();
            Map<Integer, Integer> t = new TreapMap<>();
            b.start();
            insertSorted(t);
        }
    }

    @Bench
    public static void insertRandomTreap(Bee b) {
        for (int c = 0; c < b.reps(); c++) {
            b.stop();
            Map<Integer, Integer> t = new TreapMap<>();
            b.start();
            insertRandomKeys(t);
        }
    }

    @Bench
    public static void randomLookupsTreap(Bee b) {
        for (int c = 0; c < b.reps(); c++) {
            b.stop();
            Map<Integer, Integer> t = new TreapMap<>();
            insertSorted(t);
            b.start();
            randomLookup(t);
        }
    }

    @Bench
    public static void linearLookupsTreap(Bee b) {
        for (int c = 0; c < b.reps(); c++) {
            b.stop();
            Map<Integer, Integer> t = new TreapMap<>();
            insertSorted(t);
            b.start();
            linearLookup(t);
        }
    }

    @Bench
    public static void randomRemovesTreap(Bee b) {
        for (int c = 0; c < b.reps(); c++) {
            b.stop();
            Map<Integer, Integer> t = new TreapMap<>();
            insertSorted(t);
            b.start();
            randomRemove(t);
        }
    }


}

public final class BSTTest extends TreeTestBase {

    private Map<Integer, Integer> tree = this.createTree();

    @Override
    public Map<Integer, Integer> createTree() {
        return new BinarySearchTreeMap<>();
    }
}

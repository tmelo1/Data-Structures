import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

/**
*AVL Tree implementation of OrderedMap.
*@param <K> key type
*@param <V> value type
*@author Tony Melo - tmelo1@jhu.edu
*/
public class AVLTreeMap<K extends Comparable<? super K>, V>
    implements OrderedMap<K, V> {

    private final class Node {
        Node left;
        Node right;
        K key;
        V value;
        int height;

        Node(K k, V v) {
            this.key = k;
            this.value = v;
            this.right = null;
            this.left = null;
            this.height = -1;
        }
    }

    private Node root;
    private int size;
    private StringBuilder sb;

    /**
    *Constructor for AVLTreeMap.
    */
    public AVLTreeMap() {
        this.size = 0;
    }

    @Override
    public int size() {
        return this.size;
    }

    private Node find(K k) {
        if (k == null) {
            throw new IllegalArgumentException("null keys not allowed");
        }
        Node r = this.root;
        while (r != null) {
            int compare = k.compareTo(r.key);
            if (compare < 0) {
                r = r.left;
            } else if (compare > 0) {
                r = r.right;
            } else {
                return r;
            }
        }
        return null;
    }

    private Node actuallyFind(K k) {
        Node n = this.find(k);
        if (n == null) {
            throw new IllegalArgumentException("key " + k + " not found");
        }
        return n;
    }

    @Override
    public boolean has(K k) {
        if (k == null) {
            return false;
        }
        return this.find(k) != null;
    }

    @Override
    public void put(K k, V v) {
        Node n = this.actuallyFind(k);
        n.value = v;
    }

    @Override
    public V get(K k) {
        Node n = this.actuallyFind(k);
        return n.value;
    }

    private int height(Node n) {
        if (n == null) {
            return -1;
        }
        return n.height;
    }

    private int getBalance(Node n) {
        if (n == null) {
            return -1;
        }
        if (n.right == null && n.left == null) {
            return 0;
        }
        return this.height(n.left) - this.height(n.right);
    }

    private Node insert(Node n, K k, V v) {
        if (n == null) {
            return new Node(k, v);
        }
        int compare = k.compareTo(n.key);
        if (compare < 0) {
            n.left = this.insert(n.left, k, v);
            n = this.balance(n);
        } else if (compare > 0) {
            n.right = this.insert(n.right, k, v);
            n = this.balance(n);
        } else {
            throw new IllegalArgumentException("key " + k + " is a duplicate");
        }
        return n;
    }

    @Override
    public void insert(K k, V v) {
        if (k == null) {
            throw new IllegalArgumentException("null key is invalid");
        }
        this.root = this.insert(this.root, k, v);
        this.size++;
    }

    @Override
    public V remove(K k) {
        V v = this.actuallyFind(k).value;
        this.root = this.remove(this.root, k);
        this.size--;
        return v;
    }

    private Node remove(Node n, K k) {
        if (n == null) {
            throw new IllegalArgumentException("key " + k + " not found");
        }
        int compare = k.compareTo(n.key);
        if (compare < 0) {
            n.left = this.remove(n.left, k);
            n = this.balance(n);
        } else if (compare > 0) {
            n.right = this.remove(n.right, k);
            n = this.balance(n);
        } else {
            if (n == null) {
                return n;
            }
            if (n.left == null) {
                n = n.right;
            } else if (n.right == null) {
                n = n.left;
            } else {
                Node min = this.min(n.right);
                n.key = min.key;
                n.right = this.remove(n.left, min.key);
            }
        }
        return n;

    }

    private Node balance(Node n) {
        if (n.left == null && n.right == null) {
            n.height = 0;
        } else if (n.left == null && n.right != null) {
            n.height = this.height(n.right) + 1;
        } else if (n.right == null && n.left != null) {
            n.height = this.height(n.left) + 1;
        } else {
            n.height = this.max(this.height(n.left), this.height(n.right)) + 1;
        }
        int bf = this.getBalance(n);
        if (bf > 1 && this.getBalance(n.left) >= 0) {
            return this.rightRotation(n);
        }
        if (bf > 1 && this.getBalance(n.left) < 0) {
            n.left = this.leftRotation(n.left);
            return this.rightRotation(n);
        }
        if (bf < -1 && this.getBalance(n.right) <= 0) {
            return this.leftRotation(n);
        }
        if (bf < -1 && this.getBalance(n.right) > 0) {
            n.right = this.rightRotation(n.right);
            return this.leftRotation(n);
        }
        return n;
    }


    private Node min(Node n) {
        Node temp = n;
        while (temp.left != null) {
            temp = temp.left;
        }
        return temp;
    }

    private int max(int leftHeight, int rightHeight) {
        if (leftHeight >= rightHeight) {
            return leftHeight;
        }
        return rightHeight;
    }

    private Node rightRotation(Node n) {
        Node l = n.left;
        Node r = l.right;
        l.right = n;
        n.left = r;
        n.height = this.max(this.height(n.left), this.height(n.right)) + 1;
        l.height = this.max(this.height(l.left), this.height(l.right)) + 1;
        return l;
    }

    private Node leftRotation(Node n) {
        Node r = n.right;
        n.right = r.left;
        r.left = n;
        n.height = this.max(this.height(n.left), this.height(n.right)) + 1;
        r.height = this.max(this.height(r.left), this.height(r.right)) + 1;
        return r;
    }

    // Recursively add keys from subtree rooted at given node
    // into the given list.
    private void iteratorHelper(Node n, List<K> keys) {
        if (n == null) {
            return;
        }
        this.iteratorHelper(n.left, keys);
        keys.add(n.key);
        this.iteratorHelper(n.right, keys);
    }

    @Override
    public Iterator<K> iterator() {
        List<K> keys = new ArrayList<K>();
        this.iteratorHelper(this.root, keys);
        return keys.iterator();
    }

    // If we don't have a StringBuilder yet, make one;
    // otherwise just reset it back to a clean slate.
    private void setupStringBuilder() {
        if (this.sb == null) {
            this.sb = new StringBuilder();
        } else {
            this.sb.setLength(0);
        }
    }

    // Recursively append string representations of keys and
    // values from subtree rooted at given node.
    private void toStringHelper(Node n, StringBuilder s) {
        if (n == null) {
            return;
        }
        this.toStringHelper(n.left, s);
        s.append(n.key);
        s.append(": ");
        s.append(n.value);
        s.append(", ");
        this.toStringHelper(n.right, s);
    }

    @Override
    public String toString() {
        this.setupStringBuilder();
        this.sb.append("{");

        this.toStringHelper(this.root, this.sb);

        int length = this.sb.length();
        if (length > 1) {
            // If anything was appended at all, get rid of
            // the last ", " the toStringHelper put in.
            this.sb.setLength(length - 2);
        }
        this.sb.append("}");

        return this.sb.toString();
    }
}

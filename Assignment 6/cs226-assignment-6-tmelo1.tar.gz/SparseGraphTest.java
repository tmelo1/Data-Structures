
import org.junit.Test;

public class SparseGraphTest extends GraphTestBase {

    private Graph<String, String> graph;

    @Override
    public Graph<String, String> createGraph() {
        return new SparseGraph<>();
   }

   @Test
   public void testToString() {
       Vertex<String> f = graph.insert("A");
       Vertex<String> t = graph.insert("B");
       Edge<String> e = graph.insert(f, t, "C");
       graph.label(e, 70);
       graph.label(f, 9);
       graph.label(t, 10);
       System.out.println(graph.toString());
   }
}

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public abstract class GraphTestBase {

    private Graph<String, String> graph;
    private Graph<String, String> other;

    protected abstract Graph<String, String> createGraph();

    @Before
    public void setupListTests() {
        graph = this.createGraph();
        other = this.createGraph();
    }

    @Test
    public void newGraphEmpty() {
        int c = 0;
        for (Vertex<String> s: graph.vertices()) {
            c++;
        }
        int e = 0;
        for (Edge<String> f: graph.edges()) {
            e++;
        }
        assertEquals(0, c);
        assertEquals(0, e);
    }

    @Test
    public void newVertexNoLabel() {
        Vertex<String> test = graph.insert("new vertex");
        assertEquals(null, graph.label(test));
    }

    @Test
    public void newEdgeNoLabel() {
        Vertex<String> from = graph.insert("start");
        Vertex<String> to = graph.insert("to");
        Edge<String> test = graph.insert(from, to, "testing");
        assertEquals(null, graph.label(test));
    }

    @Test(expected=RemovalException.class)
    public void cantRemoveVertexWhenHasEdges() {
        Vertex<String> test = graph.insert("test");
        Vertex<String> test2 = graph.insert("test again");
        Edge<String> test3 = graph.insert(test, test2, "t e s t");
        graph.remove(test);
    }

    @Test
    public void removeVertexWorks() {
        Vertex<String> test = graph.insert("testing");
        Vertex<String> test2 = graph.insert("test");
        Vertex<String> test3 = graph.insert("t");
        int c = 0;
        for (Vertex<String> v: graph.vertices()) {
            c++;
        }
        assertEquals(3, c);
        c = 0;
        graph.remove(test);
        for (Vertex<String> v: graph.vertices()) {
            c++;
        }
        assertEquals(2, c);
    }

    @Test
    public void removeEdgeWorks() {
        Vertex<String> test = graph.insert("t");
        Vertex<String> test2 = graph.insert("f");
        Edge<String> in = graph.insert(test, test2, "wow");
        int c = 0;
        for (Edge<String> e: graph.edges()) {
            c++;
        }
        assertEquals(1, c);
        graph.remove(in);
        for (Edge<String> e: graph.edges()) {
            c++;
        }
        assertEquals(1, c);
    }

    @Test
    public void fromWorksOnEdge() {
        Vertex<String> from = graph.insert("f");
        Vertex<String> to = graph.insert("t");
        Edge<String> test = graph.insert(from, to, "hmm");
        Vertex<String> v = graph.from(test);
        assertEquals(v.get(), from.get());
    }

    @Test
    public void toWorksOnEdge() {
        Vertex<String> from = graph.insert("f");
        Vertex<String> to = graph.insert("t");
        Edge<String> test = graph.insert(from, to, "hm");
        Vertex<String> t = graph.to(test);
        assertEquals(t.get(), to.get());
    }

    @Test(expected=PositionException.class)
    public void insertingFakeEdge() {
        Vertex<String> trueV = graph.insert("the truth");
        Vertex<String> faker = other.insert("fake");
        graph.insert(trueV, faker, "won't work");
    }

    @Test(expected=PositionException.class)
    public void fromForFakeEdge() {
        Vertex<String> fake = other.insert("fake");
        Vertex<String> stillFake = other.insert("faker");
        Edge<String> fakerStill = other.insert(fake, stillFake, "nope");
        Vertex<String> nope = graph.from(fakerStill);
    }

    @Test(expected=PositionException.class)
    public void toForFakeEdge() {
        Vertex<String> fake = other.insert("fake");
        Vertex<String> stillFake = other.insert("faker");
        Edge<String> fakerStill = other.insert(fake, stillFake, "nope");
        Vertex<String> nope = graph.to(fakerStill);
    }

    @Test(expected=PositionException.class)
    public void incomingForFakeVertex() {
        Vertex<String> fake = other.insert("fake");
        Iterable<Edge<String>> no = graph.incoming(fake);
    }

    @Test(expected=PositionException.class)
    public void outgoingingForFakeVertex() {
        Vertex<String> fake = other.insert("fake");
        Iterable<Edge<String>> no = graph.outgoing(fake);
    }

    @Test(expected=PositionException.class)
    public void labelForFakeVertex() {
        Vertex<String> fake = other.insert("fake");
        Object o = graph.label(fake);
    }

    @Test(expected=PositionException.class)
    public void labelForFakeEdge() {
        Vertex<String> fake = other.insert("fake");
        Vertex<String> stillFake = other.insert("faker");
        Edge<String> fakerStill = other.insert(fake, stillFake, "nope");
        Object nope = graph.label(fakerStill);
    }

    @Test(expected=PositionException.class)
    public void removingFakeEdge() {
        Vertex<String> fake = other.insert("fake");
        graph.remove(fake);
    }

    @Test(expected=InsertionException.class)
    public void insertingDuplicateEdge() {
        Vertex<String> t = graph.insert("h");
        Vertex<String> g = graph.insert("F");
        Edge<String> e = graph.insert(t, g, "no");
        graph.insert(t, g, "no");
    }

    @Test(expected=InsertionException.class)
    public void edgeWithDuplicateVertices() {
        Vertex<String> f = graph.insert("no");
        Edge<String> e = graph.insert(f, f, "fails");
    }

    @Test
    public void clearLabelsWorksVertices() {
        Vertex<String> n = graph.insert("np");
        graph.label(n, 70);
        assertEquals(70, graph.label(n));
        graph.clearLabels();
        assertEquals(null, graph.label(n));
    }

    @Test
    public void clearLabelsWorksEdges() {
        Vertex<String> n = graph.insert("np");
        Vertex<String> f = graph.insert("no");
        Edge<String> e = graph.insert(n, f, "huh");
        graph.label(e, 7);
        assertEquals(7, graph.label(e));
        graph.clearLabels();
        assertEquals(null, graph.label(e));
    }

    @Test
    public void clearLabelsWorks() {
        Vertex<String> n = graph.insert("np");
        Vertex<String> f = graph.insert("no");
        Edge<String> e = graph.insert(n, f, "huh");
        graph.label(e, 7);
        graph.label(n, 8);
        graph.label(f, 9);
        assertEquals(7, graph.label(e));
        assertEquals(8, graph.label(n));
        assertEquals(9, graph.label(f));
        graph.clearLabels();
        assertEquals(null, graph.label(e));
        assertEquals(null, graph.label(f));
        assertEquals(null, graph.label(n));
    }

    @Test(expected=PositionException.class)
    public void cantLabelFakeVertices() {
        Vertex<String> fake = other.insert("nah");
        graph.label(fake, 9);
    }

    @Test(expected=PositionException.class)
    public void cantLabelFakeEdges() {
        Vertex<String> fake = other.insert("no");
        Vertex<String> faker = other.insert("n");
        Edge<String> fakest = other.insert(fake, faker, "o");
        graph.label(fakest, 9);
    }

     
}

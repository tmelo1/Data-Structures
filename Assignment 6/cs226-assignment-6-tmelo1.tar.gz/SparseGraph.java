import java.util.ArrayList;

/**
 * An incidence list representation of a graph.
 * @author tmelo1
 *
 * @param <V> vertex type parameter
 * @param <E> edge type parameter
 */
public class SparseGraph<V, E> implements Graph<V, E> {
    /**
     * Inner class to represent generic vertex types.
     * @author tmelo1
     *
     * @param <V> Vertex type parameter
     */
    private final class GVertex implements Vertex<V> {
        Graph<V, E> color;
        V data;
        ArrayList<Edge<E>> incoming;
        ArrayList<Edge<E>> outgoing;
        Object label;
        int id;

        /**
         * Constructor for generic type vertex.
         * @param v the data to hold in the vertex
         */
        GVertex(V v) {
            this.data = v;
            this.color = this.getOuter();
            this.incoming = new ArrayList<Edge<E>>();
            this.outgoing = new ArrayList<Edge<E>>();
            this.label = null;
            this.id = SparseGraph.this.nextID;
        }

        private SparseGraph<V, E> getOuter() {
            return SparseGraph.this;
        }


        @Override
        public V get() {
            return this.data;
        }

        @Override
        public void put(V v) {
            this.data = v;
        }

        public int id() {
            return this.id;
        }

    }

    /**
     * An inner class to represent directed edges in the graph.
     * @author tmelo1
     *
     * @param <E> the type parameter for edges
     */
    private final class GEdge implements Edge<E> {
        Graph<V, E> color;
        Object label;
        Vertex<V> start;
        Vertex<V> end;
        E data;

        /**
         * Generic edge constructor.
         * @param from outgoing vertex of the edge
         * @param to incoming vertex of the edge
         * @param e the data for the edge
         */
        GEdge(Vertex<V> from, Vertex<V> to, E e) {
            this.start = from;
            this.end = to;
            this.data = e;
            this.color = this.getOuter();
            this.label = null;
        }

        private SparseGraph<V, E> getOuter() {
            return SparseGraph.this;
        }

        @Override
        public E get() {
            return this.data;
        }

        @Override
        public void put(E e) {
            this.data = e;
        }

    }

    /** For Angelina. */
    private int nextID;

    /** A list to hold all our vertices. */
    private ArrayList<Vertex<V>> verts;

    /** Since we can't use hashmaps,
    *having a list of edges seemed like the next best step. */
    private ArrayList<Edge<E>> edges;

    /**
     * Creates a new SparseGraph object.
     */
    public SparseGraph() {
        this.verts = new ArrayList<>();
        this.edges = new ArrayList<>();
    }

    /**
    *Get the id of a vertex.
    *@param v the vertex in question
    *@return the id of the vertex
    */
    public int id(Vertex<V> v) {
        GVertex n = this.convert(v);
        return n.id;
    }

    /**
     * Converts from general vertex to specific inner class vertex.
     * @param v the vertex to convert
     * @return the new vertex
     * @throws PositionException for invalid positions
     */
    private GVertex convert(Vertex<V> v) throws PositionException {
        try {
            GVertex n = (GVertex) v;
            if (n.color != this) {
                throw new PositionException();
            }
            return n;
        } catch (NullPointerException | ClassCastException e) {
            throw new PositionException();
        }
    }


    /**
     * Converts from general edge to specific inner class edge.
     * @param e the edge to convert
     * @return the new edge
     * @throws PositionException for invalid edges
     */
    private GEdge convert(Edge<E> e) throws PositionException {
        try {
            GEdge n = (GEdge) e;
            if (n.color != this) {
                throw new PositionException();
            }
            return n;
        } catch (NullPointerException | ClassCastException ex) {
            throw new PositionException();
        }
    }

    @Override
    public Vertex<V> insert(V v) {
        GVertex newVert = new GVertex(v);
        this.verts.add(newVert);
        this.nextID++;
        return newVert;
    }

    @Override
    public Edge<E> insert(Vertex<V> from, Vertex<V> to, E e)
        throws PositionException, InsertionException {
        if (from == to) {
            throw new InsertionException();
        }
        GVertex f = this.convert(from);
        GVertex t = this.convert(to);
        GEdge n = new GEdge(from, to, e);
        for (Edge<E> z: f.outgoing) {
            if (z.get() == n.get()) {
                throw new InsertionException();
            }
        }
       // if (f.outgoing.contains(n) || t.incoming.contains(n)) {
       //     throw new InsertionException();
       // }
        f.outgoing.add(n);
        t.incoming.add(n);
        this.edges.add(n);
        return n;
    }

    @Override
    public V remove(Vertex<V> v) throws PositionException, RemovalException {
        GVertex n = this.convert(v);
        if (!n.incoming.isEmpty() || !n.outgoing.isEmpty()) {
            throw new RemovalException();
        }
        n.color = null;
        this.verts.remove(n);
        this.nextID--;
        return n.data;
    }

    @Override
    public E remove(Edge<E> e) throws PositionException {
        GEdge r = this.convert(e);
        GVertex s = this.convert(r.start);
        GVertex endPoint = this.convert(r.end);
        boolean removed = s.outgoing.remove(r);
        if (removed) {
            endPoint.incoming.remove(r);
        } else {
            throw new PositionException();
        }
        r.color = null;
        this.edges.remove(r);
        return r.data;
    }

    @Override
    public Iterable<Vertex<V>> vertices() {
        ArrayList<Vertex<V>> vertsCopy = new ArrayList<>();
        for (Vertex<V> v: this.verts) {
            vertsCopy.add(v);
        }
        return vertsCopy;
    }

    @Override
    public Iterable<Edge<E>> edges() {
        ArrayList<Edge<E>> edgesCopy = new ArrayList<>();
        for (Edge<E> e: this.edges) {
            edgesCopy.add(e);
        }
        return edgesCopy;
    }

    @Override
    public Iterable<Edge<E>> outgoing(Vertex<V> v) throws PositionException {
        GVertex n = this.convert(v);
        ArrayList<Edge<E>> outgoingCopy = new ArrayList<>();
        for (Edge<E> e: n.incoming) {
            outgoingCopy.add(e);
        }
        return outgoingCopy;
    }

    @Override
    public Iterable<Edge<E>> incoming(Vertex<V> v) throws PositionException {
        GVertex n = this.convert(v);
        ArrayList<Edge<E>> incomingCopy = new ArrayList<>();
        for (Edge<E> e: n.incoming) {
            incomingCopy.add(e);
        }
        return incomingCopy;
    }

    @Override
    public Vertex<V> from(Edge<E> e) throws PositionException {
        GEdge n = this.convert(e);
        return n.start;
    }

    @Override
    public Vertex<V> to(Edge<E> e) throws PositionException {
        GEdge n = this.convert(e);
        return n.end;
    }

    @Override
    public void label(Vertex<V> v, Object l) throws PositionException {
        GVertex n = this.convert(v);
        n.label = l;
    }

    @Override
    public void label(Edge<E> e, Object l) throws PositionException {
        GEdge n = this.convert(e);
        n.label = l;
    }

    @Override
    public Object label(Vertex<V> v) throws PositionException {
        GVertex n = this.convert(v);
        return n.label;
    }

    @Override
    public Object label(Edge<E> e) throws PositionException {
        GEdge n = this.convert(e);
        return n.label;
    }

    @Override
    public void clearLabels() {
        for (int i = 0; i < this.verts.size(); i++) {
            GVertex v = this.convert(this.verts.get(i));
            v.label = null;
        }

        for (int i = 0; i < this.edges.size(); i++) {
            GEdge e = this.convert(this.edges.get(i));
            e.label = null;
        }
    }

    /**
     * String representation of the graph.
     * @return s the string representation
     */
    public String toString() {
        GVertex current;
        GVertex begin;
        GVertex ep;
        GEdge curr;
        String s = "digraph {\n";
        for (Vertex<V> v: this.vertices()) {
            current = this.convert(v);
            s += "    " + "\"" + current.data + "\";" + "\n";
        }
        for (Edge<E> e: this.edges()) {
            curr = this.convert(e);
            begin = this.convert(curr.start);
            ep = this.convert(curr.end);
            s +=  begin.get() + " -> " + ep.data
                + " [label= " + curr.label + "];\n";
        }
        return s;
    }
}

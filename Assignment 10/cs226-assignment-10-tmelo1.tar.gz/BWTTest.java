import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.assertEquals;
import java.io.IOException;

public final class BWTTest {

    @Test
    public void encodeWorks() throws IOException {
        BWTEncoder bwt = new BWTEncoder();
        String test = bwt.createBWT("banana");
        assertEquals("annb$aa", test);
    }

    @Test
    public void decodeWorks() throws IOException {
        String test = "annb$aa";
        String result = BWTDecoder.decodeBWT(test);
        assertEquals("banana", result);
    }
}

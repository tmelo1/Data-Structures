import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Arrays;


/**
  Builds the BWT of a string.

  Builds the BWT by sorting all of the cyclic permutations.
**/
public class BWTEncoder {

    // You may want to use this ;-)
    private final class CyclicPermutation
        implements Comparable<CyclicPermutation> {

        int index;

        CyclicPermutation(int i) {
            this.index = i;
        }

        public int compareTo(CyclicPermutation c2) {
            int off1 = this.index;
            int off2 = c2.index;

            for (int i = 0; i < BWTEncoder.this.text.length(); i++) {
                if (BWTEncoder.this.text.charAt(off1) > BWTEncoder.this.text.charAt(off2)) {
                    return 1;

                } else if (BWTEncoder.this.text.charAt(off1) < BWTEncoder.this.text.charAt(off2)) {
                    return -1;
                }
                off1 = (off1 + 1) % BWTEncoder.this.text.length();
                off2 = (off2 + 1) % BWTEncoder.this.text.length();
            }

            return 0;
        }
    }

    String text;

    /** Silence checkstyle. */
    public BWTEncoder() { }

    /** Construct the BWT of a string.

       Derives the list of possible permutations, sorts them, and then
       extracts the last colunm

       @param input The input String
       @return The BWT of the input string
    */
    public String createBWT(String input) {
        this.text = input + "$";

        StringBuilder bwt = new StringBuilder();

        // Your code here :)
        CyclicPermutation[] permute = new CyclicPermutation[this.text.length()];
        for (int i = 0; i < this.text.length(); i++) {
            CyclicPermutation c = new CyclicPermutation(i);
            permute[i] = c;
        }
        Arrays.sort(permute);
        for (int i = 0; i < permute.length; i++) {
            Character c = this.text.charAt((permute[i].index
                + this.text.length() - 1) % this.text.length());
            bwt.append(this.text.charAt((permute[i].index
                + this.text.length() - 1) % this.text.length()));
        }
        return bwt.toString();
    }

    /** Reads the input from standard in.
        @return Returns a string with the input data without newlines
        @throws IOException if the file cannot be read
    */
    public static String readInput() throws IOException {
        InputStreamReader input = new InputStreamReader(System.in);
        BufferedReader reader = new BufferedReader(input);
        StringBuilder sb = new StringBuilder();

        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }
        reader.close();
        input.close();

        return sb.toString();
    }

    /** Main method, load file into string, compute BWT.
        @param args Input arguments, ingorned
    */
    public static void main(String[] args) {
        String text = "";

        try {
            text = readInput();
        } catch (IOException e) {
            System.err.println("Cant read input");
            System.exit(1);
        }

        BWTEncoder bwt = new BWTEncoder();
        System.out.println(bwt.createBWT(text));
    }
}

import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.assertEquals;
import java.io.IOException;

public final class RLETest {

    @Test
    public void encodingWorks() throws IOException {
        String test = "this isss a tesssst";
        String result = RLEEncoder.runLengthEncode(test);
        assertEquals("this is3 a tes4t", result);
    }

    @Test
    public void decodingWorks() throws IOException {
        String test = "this isss a tesssst";
        String result = RLEEncoder.runLengthEncode(test);
        String result2 = RLEDecoder.runLengthDecode(result);
        assertEquals(result2, test);
    }

    @Test(expected=IOException.class)
    public void noEncodingNull() throws IOException {
        String test = null;
        String result = RLEEncoder.runLengthEncode(test);
    }

    @Test(expected=IOException.class) 
    public void noDecodingNull() throws IOException {
        String test = null;
        String result = RLEDecoder.runLengthDecode(test);
    }

    @Test(expected=IOException.class)
    public void noEncodingNumerals() throws IOException{
        String test = "A1";
        String result = RLEEncoder.runLengthEncode(test);
    }

    @Test(expected=IOException.class) 
    public void cantDecodeInvalidRuns() throws IOException{
        String test = "A1";
        String result = RLEDecoder.runLengthDecode(test);
    }
}

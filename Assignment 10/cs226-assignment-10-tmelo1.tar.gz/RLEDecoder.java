import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
  Computes a Run Length Encoding of a string.
**/
public final class RLEDecoder {

    /** Make checkstyle happy. */
    private RLEDecoder() { }

    /** Run Length Decode the String.

        @param input The input RLE String
        @return The decoded RLE string
        @throws IOException On invalid input
    */
    public static String runLengthDecode(String input) throws IOException {
        StringBuilder out = new StringBuilder();

        // Your code here :)
        if (input == null) {
            throw new IOException();
        }
        Character c;
        int runLength;
        for (int i = 0; i < input.length(); i++) {
            c = input.charAt(i);
            if (input.charAt(i) == input.charAt(i + 1)) {
                throw new IOException();
            }
            if (Character.isDigit(c)) {
                runLength = getLength(i, input);
                if (runLength <= 1) {
                    throw new IOException();
                }
                String offset = Integer.toString(runLength);
                int off = offset.length();
                while (runLength-- != 0) {
                    out.append(input.charAt(i - 1));
                }
                i += (off - 1);
            } else {
                if (i + 1 < input.length()
                    && !Character.isDigit(input.charAt(i + 1))) {
                    out.append(input.charAt(i));
                }
            }
        }
        return out.toString();
    }

    private static int getLength(int index, String in) {
        StringBuilder l = new StringBuilder();
        while (Character.isDigit(in.charAt(index)) && index < in.length()) {
            if (index == in.length() - 1) {
                l.append(in.charAt(index));
                break;
            }
            l.append(in.charAt(index));
            index++;
        }
        return Integer.parseInt(l.toString());
    }

    /** Reads the input from standard in.
        @return Returns a string with the input data without newlines
        @throws IOException if the file cannot be read
    */
    public static String readInput() throws IOException {
        InputStreamReader input = new InputStreamReader(System.in);
        BufferedReader reader = new BufferedReader(input);
        StringBuilder sb = new StringBuilder();

        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }
        reader.close();
        input.close();

        return sb.toString();
    }

    /** Main method, load file into string, compute BWT.
        @param args Input arguments, ingorned
    */
    public static void main(String[] args) {
        String text = "";

        try {
            text = readInput();
        } catch (IOException e) {
            System.err.println("Cant read input");
            System.exit(1);
        }

        try {
            System.out.println(runLengthDecode(text));
        } catch (IOException e) {
            System.err.println("Invalid Input");
            System.exit(1);
        }
    }
}

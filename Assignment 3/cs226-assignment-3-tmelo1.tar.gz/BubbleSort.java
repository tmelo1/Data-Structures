/**
*Implementation of bubble sort using smart cutoff if no swaps were made.
*Adapted from DSA test and modified to include early cutoff.
*Tony Melo - tmelo1@jhu.edu
@param <T>       generic comparable type to sort over
*/
public class BubbleSort<T extends Comparable<T>>
    implements SortingAlgorithm<T> {

    private boolean less(T a, T b) {
        return a.compareTo(b) < 0;
    }

    private void swap(Array<T> array, int i, int j) {
        T t = array.get(i);
        array.put(i, array.get(j));
        array.put(j, t);
    }

    @Override
    public void sort(Array<T> array) {
        boolean swapMade = true;
        int len = array.length();
        int end = len - 1;
        while (swapMade) {
            swapMade = false;
            for (int i = 0; i < len - 1; i++) {
                if (!this.less(array.get(i), array.get(i + 1))) {
                    this.swap(array, i, i + 1);
                    swapMade = true;
                }
            }
            end--;
        }
    }

    @Override
    public String name() {
        return "Bubble Sort";
    }
}

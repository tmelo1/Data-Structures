/**
*SimpleArray that holds statistics about the types of operations done.
*Tony Melo - tmelo1@jhu.edu
*@param <T> Element type
*/
public class StatableArray<T> extends SimpleArray<T> implements Statable {

    /** Store the number of write operations. */
    private int numWrites;

    /** Store the number of read operations. */
    private int numReads;

    /**
    *Create a StatableArray.
    *@param n the length of the array
    *@param t the default value to initialize with
    *@throws LengthException for invalid length arguments
    */
    public StatableArray(int n, T t) throws LengthException {
        super(n, t);
        this.numWrites = 0;
        this.numReads = 0;
    }

    /**
    *Reset the operation counters back to zero.
    */
    public void resetStatistics() {
        this.numWrites = 0;
        this.numReads = 0;
    }

    /**
    *Return how many read operations have been performed.
    *@return numReads the number of read operations
    */
    public int numberOfReads() {
        return this.numReads;
    }

    /**
    *Return how many write operations have been performed.
    *@return numWrites the number of write operations
    */
    public int numberOfWrites() {
        return this.numWrites;
    }

    @Override
    public T get(int i) throws IndexException {
        boolean inError = false;
        T t = null;
        try {
            t = super.get(i);
        } catch (IndexException e) {
            System.err.println("Caught IndexException");
            inError = true;
        }
        if (!inError) {
            this.numReads++;
        }
        return t;
    }

    @Override
    public void put(int i, T t) throws IndexException {
        boolean inError = false;
        try {
            super.put(i, t);
        } catch (IndexException e) {
            System.err.println("Caught IndexException");
            inError = true;
        }
        if (!inError) {
            this.numWrites++;
        }
    }

    @Override
    public int length() {
        this.numReads++;
        return super.length();
    }
}

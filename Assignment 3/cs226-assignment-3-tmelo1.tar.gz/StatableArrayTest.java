import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
*JUnit testing for statable arrays.
*/
public class StatableArrayTest {

    /**
    *Make sure that the initial statistics get placed properly.
    */
    @Test
    public void testInitialStats() {
        StatableArray<Integer> test = new StatableArray<>(10, 1);
        assertEquals(0, test.numberOfReads());
        assertEquals(0, test.numberOfWrites());
    }

    /**
    *Make sure that get increments the number of reads.
    */
    @Test
    public void testNumReadsAfterGet() {
        StatableArray<Integer> test = new StatableArray<>(10, 1);
        test.get(0);
        assertEquals(1, test.numberOfReads());
    }

    /**
    *Make sure that getting the length increments number of reads.
    */
    @Test
    public void testNumReadsAfterLength() {
        StatableArray<Integer> test = new StatableArray<>(10, 1);
        test.length();
        assertEquals(1, test.numberOfReads());
    }

    /**
    *Make sure that put increments the number of writes.
    */
    @Test
    public void testNumWritesAfterPut() {
        StatableArray<Integer> test = new StatableArray<>(10, 1);
        test.put(5, 42);
        assertEquals(1, test.numberOfWrites());
    }

    /**
    *Make sure that the reset function sends values back to 0.
    */
    @Test
    public void testResetStatistics() {
        StatableArray<Integer> test = new StatableArray<>(10, 1);
        test.get(0);
        test.resetStatistics();
        assertEquals(0, test.numberOfWrites());
        assertEquals(0, test.numberOfReads());
    }

    /**
    *Make sure invalid gets don't increment number of reads.
    */
    @Test
    public void testNumReadsAfterInvalidGet() {
        StatableArray<Integer> test = new StatableArray<>(10, 1);
        test.get(10);
        assertEquals(0, test.numberOfReads());
    }

    /**
    *Make sure invalid puts don't number of writes.
    */
    @Test
    public void testNumWritesAfterInvalidPut() {
        StatableArray<Integer> test = new StatableArray<>(10, 1);
        test.put(10, 10);
        assertEquals(0, test.numberOfWrites());
    }
}

/**
*Insertion sort algorithm, also adapted from DSA text.
*Tony Melo - tmelo1@jhu.edu
*@param <T> Element type.
*/
public class InsertionSort<T extends Comparable<T>>
    implements SortingAlgorithm<T> {

    private boolean less(T a, T b) {
        return a.compareTo(b) < 0;
    }

    private void swap(Array<T> a, int i, int j) {
        T t = a.get(i);
        a.put(i, a.get(j));
        a.put(j, t);
    }

    @Override
    public void sort(Array<T> array) {
        for (int i = 1; i < array.length(); i++) {
            for (int j = i; j > 0
                && this.less(array.get(i), array.get(j - 1)); j--) {
                this.swap(array, j, j - 1);
            }

        }
    }

    @Override
    public String name() {
        return "Insertion Sort";
    }
}

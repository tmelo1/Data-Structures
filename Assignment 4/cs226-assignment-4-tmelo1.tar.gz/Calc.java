import java.util.Scanner;

/**
*Implements a calculator using RPN.
*@author Tony Melo - tmelo1@jhu.edu
*/
public class Calc extends ListStack<Integer> {

    /** Regex for operators. */
    private static String operators = "\\p{Punct}";

    /** Number of integers on the stack. */
    private static int numOperands;

    /**
    *Divides first two numbers on the stack.
    *@param calc the stack representing calculator
    *@return -1 if error occured, result of the operation otherwise
    */
    public static int divide(Stack<Integer> calc) {
        if (numOperands < 2) {
            System.err.println("? Not enough arguments ?");
            return -1;
        }
        int op1 = 0;
        int op2 = 0;
        op2 = calc.top();
        calc.pop();
        op1 = calc.top();
        if (op1 == 0) {
            System.err.println("? Divide by 0 error ?");
            calc.push(op2);
            return -1;
        }
        calc.pop();
        int result = op2 / op1;
        calc.push(result);
        numOperands--;
        return result;
    }

    /**
    *Performs mod on first two numbers on the stack.
    *@param calc the stack representing calculator
    *@return -1 if error occured, result of the operation otherwise
    */
    public static int mod(Stack<Integer> calc) {
        if (numOperands < 2) {
            System.err.println("? Not enough arguments ?");
            return -1;
        }
        int op1 = 0;
        int op2 = 0;
        op2 = calc.top();
        calc.pop();
        op1 = calc.top();
        if (op1 == 0) {
            System.err.println("? Divide by 0 error ?");
            return -1;
        }
        calc.pop();
        int result = op2 % op1;
        calc.push(result);
        numOperands--;
        return result;
    }

    /**
    *Subtracts on first two numbers on the stack.
    *@param calc the stack representing calculator
    *@return -1 if error occured, result of the operation otherwise
    */
    public static int subtract(Stack<Integer> calc) {
        if (numOperands < 2) {
            System.err.println("? Not enough arguments ?");
            return -1;
        }
        int op1 = 0;
        int op2 = 0;
        op2 = calc.top();
        calc.pop();
        op1 = calc.top();
        calc.pop();
        int result = op2 - op1;
        calc.push(result);
        numOperands--;
        return result;
    }

    /**
    *Performs addition on first two numbers on the stack.
    *@param calc the stack representing calculator
    *@return -1 if error occured, result of the operation otherwise
    */
    public static int add(Stack<Integer> calc) {
        if (numOperands < 2) {
            System.err.println("? Not enough arguments ?");
            return -1;
        }
        int op2 = 0;
        int op1 = 0;
        op2 = calc.top();
        calc.pop();
        op1 = calc.top();
        calc.pop();
        int result = op1 + op2;
        calc.push(result);
        numOperands--;
        return result;
    }

    /**
    *Performs multiplication on first two numbers on the stack.
    *@param calc the stack representing calculator
    *@return -1 if error occured, result of the operation otherwise
    */
    public static int multiply(Stack<Integer> calc) {
        if (numOperands < 2) {
            System.err.println("? Not enough arguments ?");
            return -1;
        }
        int op2 = 0;
        int op1 = 0;
        op2 = calc.top();
        calc.pop();
        op1 = calc.top();
        calc.pop();
        int result = op1 * op2;
        calc.push(result);
        numOperands--;
        return result;
    }

    /**
    *Checks which operator has been entered and performs proper operation.
    *@param calc the stack representing calculator
    *@param in the string representing the operator
    *@throws EmptyException if stack is empty
    */
    public static void operations(Stack<Integer> calc, String in)
         throws EmptyException {
        switch (in) {
            case "*":
                multiply(calc);
                break;
            case ".":
                try {
                    System.out.println(calc.top());
                    calc.pop();
                } catch (EmptyException e) {
                    System.err.println("? Empty stack exception caught ?");
                }
                break;
            case "?":
                System.out.println(calc.toString());
                break;
            case "!":
                System.out.println("Exiting...");
                System.exit(0);
                break;
            case "+":
                add(calc);
                break;
            case "-":
                subtract(calc);
                break;
            case "%":
                mod(calc);
                break;
            case "/":
                divide(calc);
                break;
            default:
                System.err.println("? Invalid operator ?");
                break;
        }
    }

    /**
    *Takes input for the calculator and calls proper method based on input.
    *@param args command line arguments
    */
    public static void main(String[] args) {
        Stack<Integer> calc = new ListStack<Integer>();
        Scanner kb = new Scanner(System.in);
        String input;
        while (kb.hasNext()) {
            input = kb.next();
            if (input.matches(operators)) {
                operations(calc, input);
            } else {
                try {
                    calc.push(Integer.parseInt(input));
                    numOperands++;
                } catch (NumberFormatException e) {
                    System.err.println("? Invalid argument ?");
                }
            }
        }
    }
}

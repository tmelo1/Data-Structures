import org.junit.Test;

import static org.junit.Assert.assertEquals;

import static org.junit.Assert.assertTrue;

import static org.junit.Assert.assertFalse;

/**
*Test file for the ArrayDequeue class.
*@author Tony Melo - tmelo1@jhu.edu
*/
public class TestArrayDequeue {

    /**
    *Test method for the constructor.
    */
    @Test
    public void testConstructor() {
        ArrayDequeue<Integer> test = new ArrayDequeue<>();
        assertEquals(0, test.length());
    }

    /**
    *Test method for the insert back.
    */
    @Test
    public void testInsertBack() {
        ArrayDequeue<Integer> test = new ArrayDequeue();
        test.insertBack(1);
        test.insertBack(2);
        assertEquals("[1, 2]", test.toString());
    }

    /**
    *Test for the back method.
    */
    @Test
    public void testBack() {
        ArrayDequeue<Integer> test = new ArrayDequeue();
        test.insertBack(1);
        test.insertBack(2);
        assertEquals((int) 2, (int) test.back());
    }

    /**
    *Test for the front method.
    */
    @Test
    public void testFront() {
        ArrayDequeue<Integer> test = new ArrayDequeue();
        test.insertFront(1);
        test.insertFront(2);
        assertEquals((int) 2, (int) test.front());
    }

    /**
    *Test for the length method.
    */
    @Test
    public void testLength() {
        ArrayDequeue<Integer> test = new ArrayDequeue();
        test.insertBack(1);
        test.insertBack(2);
        assertEquals(2, test.length());
    }

    /**
    *Test for the empty method.
    */
    @Test
    public void testEmpty() {
        ArrayDequeue<Integer> test = new ArrayDequeue();
        assertTrue(test.empty());
    }

    /**
    *Test for the full method.
    */
    @Test
    public void testFull() {
        ArrayDequeue<Integer> test = new ArrayDequeue();
        test.insertBack(1);
        assertTrue(test.full());
    }

    /**
    *Test for toString.
    */
    @Test
    public void testToString() {
        ArrayDequeue<Integer> test = new ArrayDequeue();
        test.insertBack(1);
        test.insertBack(2);
        test.insertBack(3);
        assertEquals("[1, 2, 3]", test.toString());
    }

    /**
    *Test for the remove back method.
    */
    @Test
    public void testRemoveBack() {
        ArrayDequeue<Integer> test = new ArrayDequeue();
        test.insertBack(1);
        test.insertBack(2);
        test.removeBack();
        assertEquals("[1]", test.toString());
    }

    /**
    *Test for the remove front method.
    */
    @Test
    public void testRemoveFront() {
        ArrayDequeue<Integer> test = new ArrayDequeue();
        test.insertBack(1);
        test.insertBack(2);
        test.insertBack(3);
        test.removeFront();
        assertEquals("[2, 3]", test.toString());
    }

    /**
    *Testing removing at the front when the dequeue is empty.
    */
    @Test
    public void testRemoveFrontWhenEmpty() {
        ArrayDequeue<Integer> test = new ArrayDequeue();
        try {
            test.removeFront();
        } catch (EmptyException e) {
            System.out.println("Nothing to do");
        }
    }

    /**
    *Testing removing at the back when empty.
    */
    @Test
    public void testRemoveBackEmpty() {
        ArrayDequeue<Integer> test = new ArrayDequeue();
        try {
            test.removeBack();
        } catch (EmptyException e) {
            System.out.println("Nothing to do");
        }
    }

    /**
    *Test for the front method when the dequeue is empty.
    */
    @Test
    public void testFrontEmpty() {
        ArrayDequeue<Integer> test = new ArrayDequeue();
        try {
            test.front();
        } catch (EmptyException e) {
            System.out.println("Nothing to do");
        }
    }

    /**
    *Testing the back method when the dequeue is empty.
    */
    @Test
    public void testBackEmpty() {
        ArrayDequeue<Integer> test = new ArrayDequeue();
        try {
            test.back();
        } catch (EmptyException e) {
            System.out.println("Nothing to do");
        }
    }

    /**
    *Testing the resize method.
    */
    @Test
    public void testResize() {
        ArrayDequeue<Integer> test = new ArrayDequeue();
        test.insertBack(1);
        test.insertBack(2);
        test.insertBack(3);
        assertFalse(test.full());
    }

    /**
    *Testing printing the empty dequeue.
    */
    @Test
    public void testToStringEmpty() {
        ArrayDequeue<Integer> test = new ArrayDequeue();
        assertEquals("[]", test.toString());
    }

    /**
    *Testing insert at the front.
    */
    @Test
    public void testInsertFront() {
        ArrayDequeue<Integer> test = new ArrayDequeue();
        test.insertFront(1);
        test.insertFront(2);
        test.insertFront(3);
        test.insertFront(4);
        assertEquals("[4, 3, 2, 1]", test.toString());
    }


    /**
    *Testing inserting at the front then back.
    */
    @Test
    public void testInsertFrontThenBack() {
        ArrayDequeue<Integer> test = new ArrayDequeue();
        test.insertFront(1);
        test.insertBack(2);
        assertEquals("[1, 2]", test.toString());
    }

    /**
    *Testing inserting at the back then front.
    */
    @Test
    public void testInsertBackThenFront() {
        ArrayDequeue<Integer> test = new ArrayDequeue();
        test.insertBack(1);
        test.insertFront(2);
        assertEquals("[2, 1]", test.toString());
    }
}

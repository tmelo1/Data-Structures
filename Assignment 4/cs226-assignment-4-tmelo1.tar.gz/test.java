public class test {

    public static void main(String[] args) {
        String testing = "123 ";
        String[] more = testing.split(" ");
        System.out.println(more[0]);
        System.out.println(more[0].charAt(0));
    }
}

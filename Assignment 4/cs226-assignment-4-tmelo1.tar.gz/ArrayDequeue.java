/**
*Circular array based implementation of a dequeue.
*@param <T> the type of elements for the dequeue
*@author Tony Melo - tmelo1@jhu.edu
*/
public class ArrayDequeue<T> implements Dequeue<T> {

    /** Number of elements in dequeue. */
    private int numElements;

    /** Generic queue. */
    private T[] data;

    /** Index reference of front element. */
    private int front;

    /** Index reference to back. */
    private int back;


    /**
    *Makes an array dequeue object.
    */
    public ArrayDequeue() {
        this.data = (T[]) new Object[1];
        this.numElements = 0;
        this.front = 0;
        this.back = 0;

    }

    /**
    *Checks if the dequeue is empty.
    *@return true if 0 elements, false otherwise.
    */
    public boolean empty() {
        return this.numElements == 0;
    }

    /**
    *Return how many elements are in the dequeue.
    @return numElements the number of elements
    */
    public int length() {
        return this.numElements;
    }

    /**
    *Return the front element in the dequeue.
    *@return the front element
    *@throws EmptyException if the dequeue is empty.
    */
    public T front() throws EmptyException {
        if (!this.empty()) {
            return this.data[this.front];
        } else {
            throw new EmptyException();
        }
    }

    /**
    *Return the back element in the dequeue.
    *@return the back element
    *@throws EmptyException if the dequeue is empty.
    */
    public T back() throws EmptyException {
        if (!this.empty()) {
            return this.data[this.back];
        } else {
            throw new EmptyException();
        }
    }

    /**
    *Double the size of the dequeue.
    */
    public void resize() {
        int newLength = this.data.length * 2;
        T[] newRA = (T[]) new Object[newLength];
        for (int i = 0; i < this.length(); i++) {
            newRA[(this.front + i + newRA.length) % newRA.length] = this.data[(this.front + i + this.data.length) % this.data.length];
        }
        this.data = newRA;
    }


    /**
    *Return whether or not the deqeueue is full.
    *@return true if full, false otherwise
    */
    public boolean full() {
        return this.data.length == this.numElements;
    }

    /**
    *Insert an element at the front of the dequeue.
    *@param t the element to insert
    */
    public void insertFront(T t) {
        if (this.full()) {
            this.resize();
        }
        this.front = (this.front - 1 + this.data.length) % this.data.length;
        this.data[this.front] = t;
        this.numElements++;
    }

    /**
    *Insert an element at the back of the dequeue.
    *@param t the element to insert
    */
    public void insertBack(T t) {
        if (this.full()) {
            this.resize();
        }
        this.back = (this.back + 1) % this.data.length;
        this.data[this.back] = t;
        this.numElements++;
    }

    /**
    *Remove the element at the front of the dequeue.
    *@throws EmptyException if the dequeue is empty
    */
    public void removeFront() throws EmptyException {
        if (this.empty()) {
            throw new EmptyException();
        }
        this.front = (this.front + 1 + this.data.length) % this.data.length;
        this.numElements--;
    }

    /**
    *Remove the element at the back of the dequeue.
    *@throws EmptyException if the dequeue is empty
    */
    public void removeBack() throws EmptyException {
        if (this.empty()) {
            throw new EmptyException();
        }
        this.back = (this.back - 1) % this.data.length;
        this.numElements--;
    }

    /**
    *Create the string representation of the dequeue.
    *@return s the string to represent the dequeue.
    */
    public String toString() {
        String s = "[";
        for (int i = 0; i < this.length(); i++) {
            s += this.data[(this.front + i + this.data.length) % this.data.length];
            if (i != this.length() - 1) {
                s += ", ";
            }
        }
        s += "]";
        return s;
    }
}

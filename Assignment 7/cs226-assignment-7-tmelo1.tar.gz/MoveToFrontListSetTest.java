import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

public final class MoveToFrontListSetTest extends SetTestBase {

    private Set<Integer> set = this.createSet();

    @Override
    public Set<Integer> createSet() {
        return new MoveToFrontListSet<>();
    }

    @Test
    public void movingToFrontWorks() {
        for (int n = 0; n < 5; n++) {
            set.insert(n);
        }
        String s = "";
        String o = "";
        for (Integer i: set) {
            s += i + " ";
        }
        assertEquals("4 3 2 1 0 ", s);
        set.insert(2);
        for (Integer i: set) {
            o += i + " ";
        }
        assertEquals("2 4 3 1 0 ", o);
        s = "";
        set.insert(3);
        for (Integer i: set) {
            s += i + " ";
        }
        assertEquals("3 2 4 1 0 ", s);
    }
}

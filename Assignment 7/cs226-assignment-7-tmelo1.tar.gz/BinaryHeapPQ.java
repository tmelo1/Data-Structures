import java.util.Comparator;
import java.util.Collection;

/**
 * Default implementation is for a MAX Priority Queue.
 *
 * @param <T> Type of the data held in PQ.
 */

public class BinaryHeapPQ<T extends Comparable<? super T>>
    implements PriorityQueue<T> {

    /** Store items at indices 1 to N. */
    public T[] pq;
    /** Number of items in the PQ. */
    private int numItems;
    /** The comparator. */
    private Comparator<T> comparator;

    /**
     * Initializes an empty priority queue with default comparator.
     *
     */
    public BinaryHeapPQ() {
        this.pq = (T[]) (new Comparable<?>[1]);
        this.numItems = 0;
    }

    /**
     * Initializes an empty priority queue using the given comparator.
     * @param  comp the order in which to compare the keys
     */
    public BinaryHeapPQ(Comparator<T> comp) {
        this.comparator = comp;
        this.pq = (T[]) (new Comparable<?>[1]);
        this.numItems = 0;
    }

    @Override
    public boolean empty() {
        return this.numItems == 0;
    }

    /**
    *Return the number of elements in the PQ.
    *@return numItems the size
    */
    public int size() {
        return this.numItems;
    }

    @Override
    public T top() throws EmptyException {
        if (this.empty()) {
            throw new EmptyException();
        }
        return this.pq[1];
    }

    /**
     * Resizes the PQ array size when it needs more space.
     *
     * @param capacity new capacity of the PQ.
     */
    private void resize(int capacity) {
        T[] temp = (T[]) (new Comparable<?>[capacity]);
        for (int i = 1; i <= this.numItems; i++) {
            temp[i] = this.pq[i];
        }
        this.pq = temp;
    }

    @Override
    public void insert(T t) {
        if (this.numItems >= this.pq.length - 1) {
            this.resize(2 * this.pq.length);
        }
        this.pq[++this.numItems] = t;
        this.swim(this.numItems);
    }

    @Override
    public void remove() {
        if (this.empty()) {
            throw new EmptyException();
        }
        this.exch(1, this.numItems--);
        this.sink(1);
        this.pq[this.numItems + 1] = null;
        if ((this.numItems > 0)
                && (this.numItems == (this.pq.length - 1) / (2 + 2))) {
            this.resize(this.pq.length / 2);
        }
    }


   /**
    * Helper functions to keep heap structure.
    */

    /**
     * Swim up the heap.
     * @param k Index of the element to swim up
     */

    private void swim(int k) {
        while (k > 1 && this.less(k / 2, k)) {
            this.exch(k, k / 2);
            k = k / 2;
        }
    }

    /**
     * Sink down the heap.
     * @param k Index of the element to sink down
     */

    private void sink(int k) {
        while (2 * k <= this.numItems) {
            int j = 2 * k;
            if (j < this.numItems && this.less(j, j + 1)) {
                j++;
            }
            if (!this.less(k, j)) {
                break;
            }
            this.exch(k, j);
            k = j;
        }
    }

    /**
     * Checks if less than in our given comparator.
     * @param i The first index to compare
     * @param j The second index to compare
     * @return true if pq[i] < pq[j], false otherwise.
     */
    private boolean less(int i, int j) {
        if (this.comparator == null) {
            return ((Comparable<T>) this.pq[i]).compareTo(this.pq[j]) < 0;
        } else {
            return this.comparator.compare(this.pq[i], this.pq[j]) < 0;
        }
    }

    /**
     * Switches two elements in the PQ.
     * @param i First index to switch
     * @param j Second index to switch
     */
    private void exch(int i, int j) {
        T swap = this.pq[i];
        this.pq[i] = this.pq[j];
        this.pq[j] = swap;
    }

}

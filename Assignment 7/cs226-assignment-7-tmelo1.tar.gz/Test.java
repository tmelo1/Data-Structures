public final class Test {

    public static void main(String[] args) {

        Set<Integer> test1 = new TransposeArraySet<>();
        Set<Integer> test2 = new MoveToFrontListSet<>();
        test1.insert(3);
        test1.insert(4);
        test1.insert(5);
        test1.insert(29);
        test1.insert(100);

        /**
        for (int i: test1) {
            System.out.println(i);
        }
        test1.insert(100);
        for (int i: test1) {
            System.out.println(i);
        }
        test1.insert(100);
        for (int i: test1) {
            System.out.println(i);
        }
        test1.insert(100);
        for (int i: test1) {
            System.out.println(i);
        }
        test1.remove(29);
        test1.remove(4);
        for (int i: test1) {
            System.out.println(i);
        }
        */

        test2.insert(15);
        test2.insert(1);
        test2.insert(1000);
        test2.insert(50);
        for (int i: test2) {
            System.out.println(i);
        }
        test2.insert(15);
        System.out.println("\n");
        for (int i: test2) {
            System.out.println(i);
        }
        System.out.println("\n");
        test2.has(1000);
        for (int i: test2) {
            System.out.println(i);
        }
        System.out.println("\n");
        test2.remove(1);
        for (int i: test2) {
            System.out.println(i);
        }
    }
}

import java.util.Comparator;

/**
 * Comparator to get min.
 *
 * @param <T> Type being compared.
 */
public class MinComparator<T extends Comparable<? super T>> 
        implements Comparator<T> {
    /** 
     * Opposite of typical compare.
     * 
     * @param t1 first value to be compared
     * @param t2 second value to be compared
     * @return 1 if t2 < t1, 0 if equal, -1 if t2 > t1
     */
    public int compare(T t1, T t2) {
        return t2.compareTo(t1); //should be reversed order of usual
    }
}

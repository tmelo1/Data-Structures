import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public abstract class PriorityQueueTestBase {

    private PriorityQueue<Integer> q;

    protected abstract PriorityQueue<Integer> createPQ();

    @Before
    public void setupTests() {
        q = this.createPQ();
    }

    @Test
    public void newPQEmpty() {
        assertEquals(0, q.size());
    }

    @Test(expected=EmptyException.class)
    public void newPQNoTop() {
        q.top();
    }

    @Test(expected=EmptyException.class)
    public void cantRemoveWhenEmpty() {
        q.remove();
    }

    @Test
    public void insertWorks() {
        q.insert(9);
        assertEquals(1, q.size());
    }

    @Test
    public void removeWorks() {
        q.insert(1);
        q.insert(3);
        assertEquals(2, q.size());
        q.remove(3);
        assertEquals(1, q.size());
    }

    @Test
    public void emptyWorks() {
        assertTrue(q.empty());
    }

}

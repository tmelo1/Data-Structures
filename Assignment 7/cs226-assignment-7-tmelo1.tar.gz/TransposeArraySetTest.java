import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

public final class TransposeArraySetTest extends SetTestBase {

    private Set<Integer> set = this.createSet();

    @Override
    public Set<Integer> createSet() {
        return new TransposeArraySet<>();
    }

    @Test
    public void transposingWorks() {
        for (int i = 0; i < 5; i++) {
            set.insert(i);
        }
        String s = "";
        String o = "";
        for (Integer i: set) {
            s += i + " ";
        }
        assertEquals("0 1 2 3 4 ", s);
        set.insert(4);
        set.insert(4);
        set.insert(4);
        for (Integer i: set) {
            o += i + " ";
        }
        assertEquals("0 4 1 2 3 ", o);
    }

}

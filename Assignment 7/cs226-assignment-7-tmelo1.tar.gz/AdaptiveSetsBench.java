import com.github.phf.jb.Bench;
import com.github.phf.jb.Bee;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Random;
import java.io.InputStreamReader;
import java.io.File;

public final class AdaptiveSetsBench {

//    private static String path = "/home/tmelo1/cs226_2/a7/benchmarkfile";
//    private static String path2 = "/home/tmelo1/cs226_2/a7/benchmarkfile2";
    private static final int SIZE = 100;
    private static final Random RAND = new Random();

    private AdaptiveSetsBench() {}
/**
    private static void insertHalfRandom(Set<Integer> i)
        throws FileNotFoundException, IOException {
        File f = new File(path);
        FileInputStream fis = new FileInputStream(f);
        BufferedReader r = new BufferedReader(new InputStreamReader(fis));
        int in;
        for (int c = 0; c <= 10000; c++) {
            in = Integer.parseInt(r.readLine());
            i.insert(in);
        }
    }

    private static void insertBarelyRandom(Set<Integer> i)
        throws FileNotFoundException, IOException {
        File f = new File(path2);
        FileInputStream fis = new FileInputStream(f);
        BufferedReader r = new BufferedReader(new InputStreamReader(fis));
        int in;
        for (int c = 0; c <= 10000; c++) {
            in = Integer.parseInt(r.readLine());
            i.insert(in);
        }
    }
*/
    private static void insertLinear(Set<Integer> i) {
        for (int c = 0; c < SIZE; c++) {
            i.insert(c);
        }
    }

    private static void insertRandom(Set<Integer> i) {
        for (int c = 0; c < SIZE; c++) {
            i.insert(c);
        }
    }

    private static void removeRandom(Set<Integer> i) {
        for (int c = 0; c < SIZE; c++) {
            i.remove(RAND.nextInt(SIZE * 2));
        }
    }

    private static void lookupLinear(Set<Integer> i) {
        for (int c = 0; c < SIZE; c++) {
            boolean x = i.has(c);
        }
    }

    private static void lookupRandom(Set<Integer> i) {
        for (int c = 0; c < SIZE; c++) {
           boolean x = i.has(RAND.nextInt(SIZE));
        }
    }

    @Bench
    public static void insertLinearTransposeArraySet(Bee b) {
        for (int n = 0; n < b.reps(); n++) {
            b.stop();
            Set<Integer> i = new TransposeArraySet<>();
            b.start();
            insertLinear(i);
       }
    }

    @Bench
    public static void insertLinearMoveToFrontListSet(Bee b) {
       for (int n = 0; n < b.reps(); n++) {
           b.stop();
           Set<Integer> i = new MoveToFrontListSet<>();
           b.start();
           insertLinear(i);
       }
    }

    @Bench
    public static void insertRandomTransposeArraySet(Bee b) {
       for (int n = 0; n < b.reps(); n++) {
           b.stop();
           Set<Integer> i = new TransposeArraySet<>();
           b.start();
           insertRandom(i);
       }
    }

    @Bench
    public static void insertRandomMoveToFrontListSet(Bee b) {
       for (int n = 0; n < b.reps(); n++) {
           b.stop();
           Set<Integer> i = new MoveToFrontListSet<>();
           b.start();
           insertRandom(i);
       }
    }

    @Bench
    public static void removeRandomTransposeArraySet(Bee b) {
       for (int n = 0; n < b.reps(); n++) {
           b.stop();
           Set<Integer> i = new TransposeArraySet<>();
           insertRandom(i);
           b.start();
           removeRandom(i);
       }
    }

    @Bench
    public static void removeRandomMoveToFrontListSet(Bee b) {
       for (int n = 0; n < b.reps(); n++) {
           b.stop();
           Set<Integer> i = new MoveToFrontListSet<>();
           insertRandom(i);
           b.start();
           removeRandom(i);
       }
    }

    @Bench
    public static void lookupLinearTransposeArraySet(Bee b) {
       for (int n = 0; n < b.reps(); n++) {
           b.stop();
           Set<Integer> i = new TransposeArraySet<>();
           insertLinear(i);
           b.start();
           lookupLinear(i);
       }
    }

    @Bench
    public static void lookupLinearMoveToFrontListSet(Bee b) {
       for (int n = 0; n < b.reps(); n++) {
           b.stop();
           Set<Integer> i = new MoveToFrontListSet<>();
           insertLinear(i);
           b.start();
           lookupLinear(i);
       }
    }
/**
    @Bench
    public static void insertHalfRandomMoveToFrontListSet(Bee b)
        throws FileNotFoundException, IOException {
        for (int n = 0; n < b.reps(); n++) {
            b.stop();
            Set<Integer> i = new MoveToFrontListSet<>();
            insertHalfRandom(i);
            b.start();
        }
    }

    @Bench
    public static void insertHalfRandomTransposeArraySet(Bee b)
        throws FileNotFoundException, IOException {
        for (int n = 0; n < b.reps(); n++) {
            b.stop();
            Set<Integer> i = new TransposeArraySet<>();
            insertHalfRandom(i);
            b.start();
        }
    }

    @Bench
    public static void insertBarelyRandomMoveToFrontListSet(Bee b)
        throws FileNotFoundException, IOException {
        for (int n = 0; n < b.reps(); n++) {
            b.stop();
            Set<Integer> i = new MoveToFrontListSet<>();
            insertBarelyRandom(i);
            b.start();
        }
    }

    @Bench
    public static void insertBarelyRandomTransposeArraySet(Bee b)
        throws FileNotFoundException, IOException {
        for (int n = 0; n < b.reps(); n++) {
            b.stop();
            Set<Integer> i = new TransposeArraySet<>();
            insertBarelyRandom(i);
            b.start();
        }
    }
*/
}



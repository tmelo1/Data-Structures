import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import java.util.Comparator;

public final class BinaryHeapPQTest {

    private Comparator<Integer> c = new MinComparator<>();
    private BinaryHeapPQ<Integer> q = this.createPQ();
    private BinaryHeapPQ<Integer> m = this.createPQ(c);


    public BinaryHeapPQ<Integer> createPQ(Comparator<Integer> cmp) {
        return new BinaryHeapPQ(c);
    }

    public BinaryHeapPQ<Integer> createPQ() {
        return new BinaryHeapPQ<>();
    }

    @Before
    public void setupTests() {
        q = this.createPQ();
    }

    @Test
    public void newPQEmpty() {
        assertEquals(0, q.size());
    }

    @Test(expected=EmptyException.class)
    public void newPQNoTop() {
        q.top();
    }

    @Test(expected=EmptyException.class)
    public void cantRemoveWhenEmpty() {
        q.remove();
    }

    @Test
    public void insertWorks() {
        q.insert(9);
        assertEquals(1, q.size());
    }

    @Test
    public void removeWorks() {
        q.insert(1);
        q.insert(3);
        assertEquals(2, q.size());
        q.remove();
        assertEquals(1, q.size());
    }

    @Test
    public void emptyWorks() {
        assertTrue(q.empty());
    }

    @Test
    public void heapOrderingWorksForMax() {
        q.insert(1);
        q.insert(2);
        q.insert(3);
        String s = "";
        for (int i = 0; i <= q.size() + 1; i++) {
            s += q.top() + " ";
            q.remove();
        }
        assertEquals("3 2 1 ", s);
    }

    @Test
    public void heapOrderingWorksForMin() {
        m.insert(1);
        m.insert(2);
        m.insert(3);
        String s = "";
        for (int i = 0; i <= m.size() + 1; i++) {
            s += m.top() + " ";
            m.remove();
        }
        assertEquals("1 2 3 ", s);
    }

}

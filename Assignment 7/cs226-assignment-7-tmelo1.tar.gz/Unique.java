import java.util.Scanner;

/**
 * Filter unique integers from standard input to standard output.
 *
 * If you're benchmarking this program, you may want to suppress
 * the output by redirecting it to /dev/null.
 */
public final class Unique {
    private static Set<Integer> used;
    private static BinaryPQHeap<Integer> q;

    // Make checkstyle happy.
    private Unique() {}

    /**
     *  Main method.
     *  @param args Command line arguments (ignored).
     */
    public static void main(String[] args) {
        used = new MoveToFrontListSet<Integer>();
        q = new BinaryPQHeap<>();
        Scanner scanner = new Scanner(System.in);

        while (scanner.hasNextInt()) {
            int i = scanner.nextInt();
            q.insert(i);
        }

        Integer c;
        while (!q.empty()) {
            c = q.top();
            if (!used.has(c)) {
                System.out.println(c);
                used.has(c);
                used.insert(c);
            }
            q.remove();
        }
    }
}

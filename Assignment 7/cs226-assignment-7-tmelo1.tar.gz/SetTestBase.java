import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public abstract class SetTestBase {

    private Set<Integer> set;

    protected abstract Set<Integer> createSet();

    @Before
    public void setupSetTests() {
        set = this.createSet();
    }

    @Test
    public void newSetEmpty() {
       int c = 0;
       for (Integer i: set) {
           c++;
       }
       assertEquals(0, c);
    }

    @Test
    public void newSetHasAlwaysFalse() {
       boolean testing = false;
       for (int i = 0; i < 100; i++) {
           assertFalse(set.has(i));
       }
    }

    @Test
    public void insertWorks() {
       for (int i = 0; i < 10; i++) {
           set.insert(i);
       }
       int c = 0;
       for (Integer i: set) {
           c++;
       }
       assertEquals(10, c);
    }

    @Test
    public void cantInsertDupes() {
        for (int i = 0; i < 10; i++) {
            set.insert(5);
        }
        int c = 0;
        for (Integer i: set) {
            c++;
        }
        assertEquals(1, c);
    }

    @Test
    public void hasWorks() {
        for (int i = 0; i < 10; i++) {
            set.insert(i);
        }

        for (int i = 0; i < 10; i++) {
            assertTrue(set.has(i));
        }
    }

    @Test
    public void removeWorks() {
        for (int i = 0; i < 20; i++) {
            set.insert(i);
        }
        int c = 0;
        for (Integer i: set) {
            c++;
        }
        assertEquals(20, c);
        set.remove(12);
        for (Integer i: set) {
            c--;
        }
        assertEquals(1, c);
    }

    @Test
    public void removeOnFakeValue() {
        for (int i = 0; i < 10; i++) {
            set.insert(i);
        }
        int c = 0;
        for (Integer i: set) {
            c++;
        }
        assertEquals(10, c);
        set.remove(11);
        for (Integer i: set) {
            c--;
        }
        assertEquals(0, c);
    }
}
